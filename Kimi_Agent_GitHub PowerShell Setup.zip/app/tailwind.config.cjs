/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        tropicale: {
          bg: '#F5F5F5',
          text: '#1A1A1A',
          white: '#FFFFFF',
          item: '#FFFFFF',
          hover: '#ECECEC',
          border: '#E0E0E0',
          success: '#4CAF50',
          warning: '#FF9800',
          error: '#F44336',
          info: '#2196F3',
        },
        ice: {
          cream: '#F5F5F5',
          bg: '#E8E8E8',
          brown: '#3E2723',
        },
      },
      fontFamily: {
        display: ['Montserrat', 'system-ui', 'sans-serif'],
        body: ['Inter', 'system-ui', 'sans-serif'],
        mono: ['Fira Code', 'monospace'],
      },
      borderRadius: {
        'card': '24px',
        'btn': '16px',
        'pill': '50px',
      },
      boxShadow: {
        'card': '0 4px 20px rgba(0,0,0,0.08)',
        'card-hover': '0 8px 30px rgba(0,0,0,0.12)',
        'btn': '0 4px 15px rgba(76,175,80,0.3)',
        'btn-hover': '0 6px 20px rgba(76,175,80,0.4)',
      },
    },
  },
  plugins: [],
}
