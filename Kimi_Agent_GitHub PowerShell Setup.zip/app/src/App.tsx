import { useEffect } from 'react';
import { useStore } from '@/store/useStore';
import AppSelector from '@/components/AppSelector';
import ClienteApp from '@/apps/cliente/ClienteApp';
import CocinaApp from '@/apps/cocina/CocinaApp';
import KioskApp from '@/apps/kiosk/KioskApp';
import AdminApp from '@/apps/admin/AdminApp';

export default function App() {
  const { view, setView, setNotificacao, limparNotificacao } = useStore();

  // Listener global para sincronia entre apps
  useEffect(() => {
    let bc: BroadcastChannel | null = null;
    try {
      bc = new BroadcastChannel('tropicale_status');
      bc.onmessage = (event) => {
        const data = event.data;
        if (data?.type === 'STATUS_UPDATE' && data.estado === 'listo') {
          // Notificacao amigavel quando pedido fica pronto
          setNotificacao({
            tipo: 'pronto',
            mensagem: '🍦 Seu sorvete ta pronto! Vem buscar!',
            pedidoId: data.pedidoId,
          });

          // Vibração no mobile
          if (navigator.vibrate) {
            navigator.vibrate([200, 100, 200, 100, 400]);
          }

          // Auto-limpar apos 8s
          setTimeout(() => limparNotificacao(), 8000);
        }
      };
    } catch { /* BroadcastChannel nao suportado */ }

    return () => { if (bc) bc.close(); };
  }, [setNotificacao, limparNotificacao]);

  return (
    <>
      {view === 'selector' && <AppSelector />}
      {view === 'cliente' && <ClienteApp />}
      {view === 'cocina' && <CocinaApp />}
      {view === 'kiosk' && <KioskApp />}
      {view === 'admin' && <AdminApp />}
    </>
  );
}
