export interface Produto {
  id: string;
  nome: string;
  preco: number;
  imagem: string;
  categoria: 'acai' | 'crema' | 'picole' | 'yogurt' | 'picole-premium' | 'picole-duplo' | 'conos' | 'melhorados' | 'sundae' | 'sabores-especiais' | 'yogurt-especial' | 'barquillo' | 'donuts';
  descricao?: string;
  emEstoque: boolean;
  origem?: 'brasil' | 'argentina' | 'espanha';
}

export interface ItemCarrinho {
  produto: Produto;
  quantidade: number;
  observacoes?: string;
}

export interface PedidoCliente {
  id: string;
  itens: ItemCarrinho[];
  total: number;
  estado: 'pendente' | 'preparando' | 'listo' | 'entregado' | 'cancelado';
  origem: 'pwa';
  timestamp: number;
  usuarioId: string;
  nomeUsuario: string;
  emailUsuario: string;
  metodoPago: string;
  telefone?: string;
}

export interface PedidoKDS {
  id: string;
  numero: number;
  itens: string[];
  estado: 'pendente' | 'preparando' | 'listo' | 'entregado' | 'cancelado';
  origem: 'tpv' | 'pwa';
  timestamp: number;
  total: number;
  usuario?: { nome: string; email: string; telefone?: string };
}

export interface Usuario {
  id: string;
  nome: string;
  email: string;
  telefone?: string;
  logado: boolean;
}

export interface EstadoCarrinho {
  itens: ItemCarrinho[];
  aberto: boolean;
  passo: 'carrinho' | 'endereco' | 'pagamento';
}

export type ViewMode = 'selector' | 'cliente' | 'cocina' | 'kiosk' | 'admin';
