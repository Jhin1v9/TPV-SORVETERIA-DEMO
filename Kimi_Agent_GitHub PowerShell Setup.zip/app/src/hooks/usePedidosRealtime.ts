import { useEffect } from 'react';
import { useStore } from '@/store/useStore';

export function usePedidosRealtime() {
  const { pedidosKDS } = useStore();

  useEffect(() => {
    let bc: BroadcastChannel | null = null;
    try {
      bc = new BroadcastChannel('tropicale_orders');
      bc.onmessage = (event) => {
        if (event.data?.type === 'NEW_ORDER') {
          // O pedido ja foi adicionado pelo addPedidoKDS que dispara o broadcast
          // Aqui so precisamos sincronizar via localStorage para multi-tab
        }
      };
    } catch {
      // BroadcastChannel nao suportado
    }

    // Sync via localStorage para cross-tab
    const handleStorage = (e: StorageEvent) => {
      if (e.key === 'tropicale_kds' && e.newValue) {
        try {
          const pedidos = JSON.parse(e.newValue);
          useStore.setState({ pedidosKDS: pedidos });
        } catch { /* noop */ }
      }
    };
    window.addEventListener('storage', handleStorage);

    return () => {
      if (bc) bc.close();
      window.removeEventListener('storage', handleStorage);
    };
  }, []);
}
