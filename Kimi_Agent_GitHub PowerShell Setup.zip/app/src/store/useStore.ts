import { create } from 'zustand';
import type { Usuario, ItemCarrinho, PedidoCliente, PedidoKDS, ViewMode } from '@/types';

interface AppState {
  view: ViewMode;
  setView: (v: ViewMode) => void;

  usuario: Usuario | null;
  setUsuario: (u: Usuario | null) => void;
  login: (nome: string, email: string, telefone?: string) => void;
  logout: () => void;

  carrinho: ItemCarrinho[];
  carrinhoAberto: boolean;
  addItem: (item: ItemCarrinho) => void;
  removeItem: (id: string) => void;
  updateQuantidade: (id: string, qtd: number) => void;
  clearCarrinho: () => void;
  toggleCarrinho: () => void;
  abrirCarrinho: () => void;
  fecharCarrinho: () => void;
  totalCarrinho: () => number;

  pedidosCliente: PedidoCliente[];
  addPedido: (pedido: PedidoCliente) => void;
  atualizarEstadoPedido: (id: string, estado: PedidoCliente['estado']) => void;

  pedidosKDS: PedidoKDS[];
  addPedidoKDS: (pedido: PedidoKDS) => void;
  atualizarEstadoKDS: (id: string, estado: PedidoKDS['estado']) => void;

  busca: string;
  setBusca: (b: string) => void;
  categoriaAtiva: string;
  setCategoriaAtiva: (c: string) => void;

  // Notificacao amigavel
  notificacao: { tipo: 'pronto' | 'info' | null; mensagem: string; pedidoId?: string };
  setNotificacao: (n: { tipo: 'pronto' | 'info' | null; mensagem: string; pedidoId?: string }) => void;
  limparNotificacao: () => void;

  // Configuracoes PWA
  configuracoes: { alergenos: string[]; tema: 'claro' | 'escuro' };
  toggleAlergeno: (a: string) => void;
  setTema: (t: 'claro' | 'escuro') => void;
}

const CONFIG_KEY = 'tropicale_config';

function loadConfig() {
  try {
    const saved = localStorage.getItem(CONFIG_KEY);
    if (saved) return JSON.parse(saved);
  } catch { /* noop */ }
  return { alergenos: [], tema: 'claro' as const };
}

export const useStore = create<AppState>((set, get) => ({
  view: 'selector',
  setView: (v) => set({ view: v }),

  usuario: (() => {
    try { const saved = localStorage.getItem('tropicale_user'); return saved ? JSON.parse(saved) : null; }
    catch { return null; }
  })(),
  setUsuario: (u) => {
    if (u) localStorage.setItem('tropicale_user', JSON.stringify(u));
    else localStorage.removeItem('tropicale_user');
    set({ usuario: u });
  },
  login: (nome, email, telefone) => {
    const u = { id: `u_${Date.now()}`, nome, email, telefone, logado: true };
    localStorage.setItem('tropicale_user', JSON.stringify(u));
    set({ usuario: u });
  },
  logout: () => {
    localStorage.removeItem('tropicale_user');
    set({ usuario: null, carrinho: [] });
  },

  carrinho: [],
  carrinhoAberto: false,
  addItem: (item) => {
    const c = get().carrinho;
    const exist = c.find((i) => i.produto.id === item.produto.id);
    if (exist) {
      set({ carrinho: c.map((i) => i.produto.id === item.produto.id ? { ...i, quantidade: i.quantidade + item.quantidade } : i) });
    } else {
      set({ carrinho: [...c, item] });
    }
  },
  removeItem: (id) => set({ carrinho: get().carrinho.filter((i) => i.produto.id !== id) }),
  updateQuantidade: (id, qtd) => {
    if (qtd <= 0) {
      set({ carrinho: get().carrinho.filter((i) => i.produto.id !== id) });
    } else {
      set({ carrinho: get().carrinho.map((i) => i.produto.id === id ? { ...i, quantidade: qtd } : i) });
    }
  },
  clearCarrinho: () => set({ carrinho: [], carrinhoAberto: false }),
  toggleCarrinho: () => set((s) => ({ carrinhoAberto: !s.carrinhoAberto })),
  abrirCarrinho: () => set({ carrinhoAberto: true }),
  fecharCarrinho: () => set({ carrinhoAberto: false }),
  totalCarrinho: () => get().carrinho.reduce((sum, i) => sum + i.produto.preco * i.quantidade, 0),

  pedidosCliente: (() => {
    try { const saved = localStorage.getItem('tropicale_pedidos'); return saved ? JSON.parse(saved) : []; }
    catch { return []; }
  })(),
  addPedido: (pedido) => {
    const pedidos = [pedido, ...get().pedidosCliente];
    localStorage.setItem('tropicale_pedidos', JSON.stringify(pedidos));
    set({ pedidosCliente: pedidos });
  },
  atualizarEstadoPedido: (id, estado) => {
    const pedidos = get().pedidosCliente.map((p) => p.id === id ? { ...p, estado } : p);
    localStorage.setItem('tropicale_pedidos', JSON.stringify(pedidos));
    set({ pedidosCliente: pedidos });
  },

  pedidosKDS: (() => {
    try { const saved = localStorage.getItem('tropicale_kds'); return saved ? JSON.parse(saved) : []; }
    catch { return []; }
  })(),
  addPedidoKDS: (pedido) => {
    const pedidos = [pedido, ...get().pedidosKDS];
    localStorage.setItem('tropicale_kds', JSON.stringify(pedidos));
    set({ pedidosKDS: pedidos });
    try {
      const bc = new BroadcastChannel('tropicale_orders');
      bc.postMessage({ type: 'NEW_ORDER', pedido });
      bc.close();
    } catch { /* noop */ }
  },
  atualizarEstadoKDS: (id, estado) => {
    const pedidos = get().pedidosKDS.map((p) => p.id === id ? { ...p, estado } : p);
    localStorage.setItem('tropicale_kds', JSON.stringify(pedidos));
    set({ pedidosKDS: pedidos });
    // Broadcast para notificar cliente
    try {
      const bc = new BroadcastChannel('tropicale_status');
      bc.postMessage({ type: 'STATUS_UPDATE', pedidoId: id, estado });
      bc.close();
    } catch { /* noop */ }
  },

  busca: '',
  setBusca: (b) => set({ busca: b }),
  categoriaAtiva: 'todos',
  setCategoriaAtiva: (c) => set({ categoriaAtiva: c }),

  // Notificacao
  notificacao: { tipo: null, mensagem: '' },
  setNotificacao: (n) => set({ notificacao: n }),
  limparNotificacao: () => set({ notificacao: { tipo: null, mensagem: '' } }),

  // Configuracoes
  configuracoes: loadConfig(),
  toggleAlergeno: (a) => {
    const cfg = get().configuracoes;
    const alergenos = cfg.alergenos.includes(a)
      ? cfg.alergenos.filter((x) => x !== a)
      : [...cfg.alergenos, a];
    const novo = { ...cfg, alergenos };
    localStorage.setItem(CONFIG_KEY, JSON.stringify(novo));
    set({ configuracoes: novo });
  },
  setTema: (t) => {
    const cfg = { ...get().configuracoes, tema: t };
    localStorage.setItem(CONFIG_KEY, JSON.stringify(cfg));
    set({ configuracoes: cfg });
  },
}));
