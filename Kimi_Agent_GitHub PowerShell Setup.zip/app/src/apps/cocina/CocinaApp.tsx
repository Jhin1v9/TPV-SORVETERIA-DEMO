import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useStore } from '@/store/useStore';
import { usePedidosRealtime } from '@/hooks/usePedidosRealtime';
import {
  ChefHat, Package, CheckCircle, Truck, Volume2, VolumeX,
  ArrowLeft, Clock, Users, RefreshCw, Filter, Smartphone, Monitor
} from 'lucide-react';

const statusConfig = {
  pendente: { label: 'Pendente', color: 'bg-blue-500', bg: 'bg-blue-50', border: 'border-blue-200', text: 'text-blue-700', icon: Package },
  preparando: { label: 'Preparando', color: 'bg-orange-500', bg: 'bg-orange-50', border: 'border-orange-200', text: 'text-orange-700', icon: ChefHat },
  listo: { label: 'Pronto', color: 'bg-green-500', bg: 'bg-green-50', border: 'border-green-200', text: 'text-green-700', icon: CheckCircle },
  entregado: { label: 'Entregue', color: 'bg-gray-400', bg: 'bg-gray-50', border: 'border-gray-200', text: 'text-gray-500', icon: Truck },
};

export default function CocinaApp() {
  const { pedidosKDS, atualizarEstadoKDS, setView } = useStore();
  usePedidosRealtime();
  const [filtro, setFiltro] = useState<'todos' | 'tpv' | 'pwa'>('todos');
  const [somAtivo, setSomAtivo] = useState(true);
  const [hora, setHora] = useState(new Date());

  useEffect(() => {
    const interval = setInterval(() => setHora(new Date()), 1000);
    return () => clearInterval(interval);
  }, []);

  // Notificacao sonora para novos pedidos
  const ultimoPedido = pedidosKDS[0];
  useEffect(() => {
    if (ultimoPedido?.estado === 'pendente' && somAtivo) {
      try {
        const ctx = new AudioContext();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.frequency.value = 880;
        gain.gain.value = 0.15;
        osc.start();
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.3);
        osc.stop(ctx.currentTime + 0.3);
      } catch { /* noop */ }
    }
  }, [ultimoPedido?.id, somAtivo]);

  const pedidosAtivos = pedidosKDS.filter((p) => {
    if (p.estado === 'entregado' || p.estado === 'cancelado') return false;
    if (filtro === 'todos') return true;
    return p.origem === filtro;
  });

  const stats = {
    total: pedidosKDS.filter((p) => p.estado !== 'entregado' && p.estado !== 'cancelado').length,
    tpv: pedidosKDS.filter((p) => p.origem === 'tpv' && p.estado !== 'entregado').length,
    pwa: pedidosKDS.filter((p) => p.origem === 'pwa' && p.estado !== 'entregado').length,
    pendentes: pedidosKDS.filter((p) => p.estado === 'pendente').length,
  };

  const avancarEstado = (id: string, estadoAtual: string) => {
    const sequencia = ['pendente', 'preparando', 'listo', 'entregado'];
    const idx = sequencia.indexOf(estadoAtual);
    if (idx >= 0 && idx < sequencia.length - 1) {
      atualizarEstadoKDS(id, sequencia[idx + 1] as keyof typeof statusConfig);
    }
  };

  return (
    <div className="min-h-screen bg-[#1a1a2e] text-white">
      {/* Top Bar */}
      <header className="sticky top-0 z-50 bg-[#16213e]/95 backdrop-blur border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button onClick={() => setView('selector')} className="p-2 -ml-2 text-gray-400 hover:text-white transition-colors">
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2">
              <ChefHat className="w-6 h-6 text-orange-400" />
              <h1 className="font-display font-bold text-lg hidden sm:block">Cocina KDS</h1>
            </div>
          </div>

          {/* Stats */}
          <div className="hidden md:flex items-center gap-4">
            <div className="flex items-center gap-1.5 bg-white/10 px-3 py-1.5 rounded-lg">
              <Clock className="w-4 h-4 text-gray-400" />
              <span className="font-mono text-sm">{hora.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}</span>
            </div>
            <div className="flex items-center gap-1.5 bg-blue-500/20 px-3 py-1.5 rounded-lg">
              <Package className="w-4 h-4 text-blue-400" />
              <span className="text-sm font-medium">{stats.pendentes} pendente{stats.pendentes !== 1 ? 's' : ''}</span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button onClick={() => setSomAtivo(!somAtivo)} className={`p-2 rounded-lg transition-colors ${somAtivo ? 'bg-green-500/20 text-green-400' : 'bg-white/10 text-gray-400'}`}>
              {somAtivo ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </header>

      {/* Filtros */}
      <div className="max-w-7xl mx-auto px-4 py-3">
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar">
          <Filter className="w-4 h-4 text-gray-400 flex-shrink-0" />
          {[
            { key: 'todos' as const, label: 'Todos', count: stats.total },
            { key: 'tpv' as const, label: 'TPV Tablet', count: stats.tpv, icon: Monitor },
            { key: 'pwa' as const, label: 'PWA App', count: stats.pwa, icon: Smartphone },
          ].map((f) => (
            <button
              key={f.key}
              onClick={() => setFiltro(f.key)}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-medium transition-all flex-shrink-0 ${
                filtro === f.key ? 'bg-orange-500 text-white' : 'bg-white/10 text-gray-400 hover:bg-white/20'
              }`}
            >
              {'icon' in f && f.icon && <f.icon className="w-4 h-4" />}
              {f.label}
              <span className={`text-xs px-1.5 py-0.5 rounded-full ${filtro === f.key ? 'bg-white/20' : 'bg-white/10'}`}>{f.count}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Grid de pedidos */}
      <div className="max-w-7xl mx-auto px-4 pb-8">
        {pedidosAtivos.length === 0 ? (
          <div className="text-center py-20">
            <ChefHat className="w-16 h-16 mx-auto text-gray-600 mb-4" />
            <p className="text-gray-400 text-lg">Nenhum pedido ativo</p>
            <p className="text-gray-500 text-sm mt-1">Os pedidos aparecerao aqui automaticamente</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <AnimatePresence>
              {pedidosAtivos.map((pedido) => {
                const config = statusConfig[pedido.estado as keyof typeof statusConfig] || statusConfig.pendente;
                const StatusIcon = config.icon;
                const tempo = Math.floor((Date.now() - pedido.timestamp) / 1000);
                const min = Math.floor(tempo / 60);
                const seg = tempo % 60;

                return (
                  <motion.div
                    key={pedido.id}
                    layout
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    className={`rounded-xl border-2 ${config.border} ${config.bg} p-5`}
                  >
                    {/* Header */}
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-2xl font-bold text-gray-800">#{String(pedido.numero).padStart(3, '0')}</span>
                          {pedido.origem === 'pwa' ? (
                            <span className="badge-pwa">
                              <Smartphone className="w-3 h-3" /> PWA
                            </span>
                          ) : (
                            <span className="badge-kiosk">
                              <Monitor className="w-3 h-3" /> TPV
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-gray-400 mt-1">{new Date(pedido.timestamp).toLocaleTimeString('pt-BR')}</p>
                      </div>
                      <div className={`w-10 h-10 rounded-full ${config.color} flex items-center justify-center text-white`}>
                        <StatusIcon className="w-5 h-5" />
                      </div>
                    </div>

                    {/* Usuario (se PWA) */}
                    {pedido.usuario && (
                      <div className="flex items-center gap-2 mb-3 bg-white/50 rounded-lg px-3 py-2">
                        <Users className="w-4 h-4 text-gray-400" />
                        <div className="min-w-0">
                          <p className="text-sm font-medium text-gray-700 truncate">{pedido.usuario.nome}</p>
                          <p className="text-xs text-gray-400 truncate">{pedido.usuario.telefone || pedido.usuario.email}</p>
                        </div>
                      </div>
                    )}

                    {/* Itens */}
                    <div className="space-y-1 mb-4">
                      {pedido.itens.map((item, i) => (
                        <p key={i} className="text-sm text-gray-600">{item}</p>
                      ))}
                    </div>

                    {/* Footer */}
                    <div className="flex items-center justify-between pt-3 border-t border-gray-200/50">
                      <div className="flex items-center gap-1.5">
                        <Clock className="w-4 h-4 text-gray-400" />
                        <span className="font-mono text-sm text-gray-500">
                          {String(min).padStart(2, '0')}:{String(seg).padStart(2, '0')}
                        </span>
                      </div>
                      <span className="font-mono font-bold text-gray-800">{pedido.total.toFixed(2)} &euro;</span>
                    </div>

                    {/* Acao */}
                    {pedido.estado !== 'entregado' && (
                      <motion.button
                        whileTap={{ scale: 0.97 }}
                        onClick={() => avancarEstado(pedido.id, pedido.estado)}
                        className={`w-full mt-4 h-11 rounded-lg font-semibold text-sm text-white transition-colors ${config.color} hover:opacity-90 flex items-center justify-center gap-2`}
                      >
                        <RefreshCw className="w-4 h-4" />
                        {pedido.estado === 'pendente' ? 'Iniciar preparo' :
                         pedido.estado === 'preparando' ? 'Marcar pronto' :
                         pedido.estado === 'listo' ? 'Marcar entregue' : ''}
                      </motion.button>
                    )}
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>
        )}
      </div>
    </div>
  );
}
