import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useStore } from '@/store/useStore';
import { PRODUTOS, CATEGORIAS } from '@/data/cardapio';
import type { Produto } from '@/types';
import {
  Plus, Minus, Trash2, ShoppingCart, ArrowRight, X,
  CreditCard, QrCode, Check, Sparkles
} from 'lucide-react';

type KioskView = 'welcome' | 'categorias' | 'produtos' | 'carrinho' | 'pagamento';

export default function KioskApp() {
  const { setView } = useStore();
  const [kv, setKv] = useState<KioskView>('welcome');
  const [catAtiva, setCatAtiva] = useState('todos');
  const [carrinhoLocal, setCarrinhoLocal] = useState<Array<{ produto: Produto; qtd: number }>>([]);
  const [payStep, setPayStep] = useState(0);
  const [confetti, setConfetti] = useState<Array<{ id: number; x: number; y: number; color: string; rot: number }>>([]);
  const inactivityTimer = useRef<ReturnType<typeof setTimeout>>();

  // Reset apos inatividade
  const resetTimer = () => {
    if (inactivityTimer.current) clearTimeout(inactivityTimer.current);
    if (kv !== 'welcome') {
      inactivityTimer.current = setTimeout(() => {
        setKv('welcome');
        setCarrinhoLocal([]);
      }, 120000); // 2 minutos
    }
  };

  useEffect(() => {
    resetTimer();
    window.addEventListener('click', resetTimer);
    window.addEventListener('touchstart', resetTimer);
    return () => {
      window.removeEventListener('click', resetTimer);
      window.removeEventListener('touchstart', resetTimer);
      if (inactivityTimer.current) clearTimeout(inactivityTimer.current);
    };
  }, [kv]);

  const addCarrinho = (p: Produto) => {
    setCarrinhoLocal((prev) => {
      const exist = prev.find((i) => i.produto.id === p.id);
      if (exist) return prev.map((i) => i.produto.id === p.id ? { ...i, qtd: i.qtd + 1 } : i);
      return [...prev, { produto: p, qtd: 1 }];
    });
  };

  const updateQtd = (id: string, qtd: number) => {
    if (qtd <= 0) setCarrinhoLocal((prev) => prev.filter((i) => i.produto.id !== id));
    else setCarrinhoLocal((prev) => prev.map((i) => i.produto.id === id ? { ...i, qtd } : i));
  };

  const total = carrinhoLocal.reduce((s, i) => s + i.produto.preco * i.qtd, 0);
  const qtdTotal = carrinhoLocal.reduce((s, i) => s + i.qtd, 0);

  const produtosFiltrados = PRODUTOS.filter((p) => catAtiva === 'todos' || p.categoria === catAtiva);

  // Gerar confetti
  const gerarConfetti = () => {
    const colors = ['#4CAF50', '#2196F3', '#FF9800', '#E91E63', '#9C27B0', '#FFD700', '#00BCD4'];
    const particles = Array.from({ length: 80 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * -50,
      color: colors[Math.floor(Math.random() * colors.length)],
      rot: Math.random() * 360,
    }));
    setConfetti(particles);
  };

  const processarPagamento = () => {
    setKv('pagamento');
    setPayStep(0);
    // Fases animacao
    setTimeout(() => setPayStep(1), 1500);
    setTimeout(() => setPayStep(2), 3000);
    setTimeout(() => { setPayStep(3); gerarConfetti(); }, 4500);
    setTimeout(() => { setKv('welcome'); setCarrinhoLocal([]); setPayStep(0); setConfetti([]); }, 12000);
  };

  // ===== WELCOME SCREEN =====
  if (kv === 'welcome') {
    return (
      <div className="h-screen w-screen bg-gradient-to-br from-emerald-500 via-green-500 to-yellow-400 flex flex-col items-center justify-center select-none overflow-hidden">
        {/* Particulas flutuantes */}
        {Array.from({ length: 20 }).map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-4 h-4 bg-white/20 rounded-full"
            style={{ left: `${Math.random() * 100}%`, top: `${Math.random() * 100}%` }}
            animate={{ y: [0, -30, 0], opacity: [0.2, 0.5, 0.2] }}
            transition={{ duration: 3 + Math.random() * 2, repeat: Infinity, delay: Math.random() * 2 }}
          />
        ))}

        <motion.div
          initial={{ scale: 0, rotate: -180 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{ type: 'spring', stiffness: 100, damping: 15 }}
          className="mb-8"
        >
          <div className="w-40 h-40 bg-white rounded-3xl flex items-center justify-center shadow-2xl">
            <svg viewBox="0 0 64 64" className="w-24 h-24" fill="none">
              <path d="M32 12 C20 12, 12 20, 12 30 C12 42, 20 48, 32 48 C44 48, 52 42, 52 30 C52 20, 44 12, 32 12Z" fill="#4CAF50" opacity="0.9" />
              <path d="M20 28 Q32 52 44 28" stroke="#3E2723" strokeWidth="3" fill="none" strokeLinecap="round" />
              <circle cx="24" cy="22" r="2" fill="#FFF" opacity="0.8" />
              <circle cx="38" cy="20" r="2.5" fill="#8D6E63" opacity="0.5" />
            </svg>
          </div>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="font-display text-7xl font-extrabold text-white mb-4 text-center drop-shadow-lg"
        >
          Tropicale
        </motion.h1>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="text-3xl text-white/90 mb-16 font-light"
        >
          Gelats Artesanais desde 1996
        </motion.p>

        <motion.button
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setKv('categorias')}
          className="bg-white text-green-600 text-4xl font-bold py-8 px-24 rounded-3xl shadow-2xl hover:shadow-white/30 transition-shadow flex items-center gap-4"
          style={{ minHeight: '140px' }}
        >
          <svg viewBox="0 0 24 24" className="w-12 h-12" fill="currentColor">
            <path d="M12 2C8.5 2 6 4.5 6 7c0 1.5.5 2.5 1.5 3.5V19c0 1.66 1.34 3 3 3s3-1.34 3-3v-8.5C13.5 9.5 14 8.5 14 7c0-2.5-2.5-5-5-5z"/>
          </svg>
          Iniciar Pedido
        </motion.button>

        <motion.button
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.9 }}
          onClick={() => setView('selector')}
          className="mt-8 text-white/70 text-2xl hover:text-white transition-colors underline"
        >
          Voltar ao menu
        </motion.button>
      </div>
    );
  }

  // ===== CATEGORIAS =====
  if (kv === 'categorias') {
    return (
      <div className="h-screen w-screen bg-gray-50 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="h-24 bg-white border-b flex items-center justify-between px-10">
          <button onClick={() => setKv('welcome')} className="text-3xl font-bold text-gray-400 hover:text-gray-600">Voltar</button>
          <h1 className="font-display text-5xl font-bold text-gray-800">Escolha uma Categoria</h1>
          <button onClick={() => setKv('carrinho')} className="relative">
            <ShoppingCart className="w-10 h-10 text-green-600" />
            {qtdTotal > 0 && (
              <span className="absolute -top-2 -right-2 bg-green-500 text-white font-bold w-8 h-8 rounded-full flex items-center justify-center text-lg">{qtdTotal}</span>
            )}
          </button>
        </div>

        {/* Grid categorias */}
        <div className="flex-1 p-10 overflow-auto">
          <div className="grid grid-cols-3 lg:grid-cols-4 gap-8 max-w-7xl mx-auto">
            {CATEGORIAS.map((cat, idx) => (
              <motion.button
                key={cat.id}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.06 }}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.97 }}
                onClick={() => { setCatAtiva(cat.id); setKv('produtos'); }}
                className="bg-white rounded-3xl shadow-lg p-8 flex flex-col items-center gap-4 hover:shadow-xl transition-shadow border-2 border-transparent hover:border-green-200"
                style={{ minHeight: '280px' }}
              >
                <span className="text-8xl">{cat.emoji}</span>
                <span className="font-display text-3xl font-bold text-gray-800 text-center">{cat.nome}</span>
                <span className="text-xl text-gray-400">{PRODUTOS.filter((p) => p.categoria === cat.id).length} produtos</span>
              </motion.button>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // ===== PRODUTOS =====
  if (kv === 'produtos') {
    return (
      <div className="h-screen w-screen bg-gray-50 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="h-24 bg-white border-b flex items-center justify-between px-10">
          <button onClick={() => setKv('categorias')} className="text-3xl font-bold text-gray-400 hover:text-gray-600 flex items-center gap-2">
            <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" /></svg>
            Categorias
          </button>
          <h1 className="font-display text-4xl font-bold text-gray-800">{CATEGORIAS.find((c) => c.id === catAtiva)?.nome || 'Todos'}</h1>
          <button onClick={() => setKv('carrinho')} className="relative">
            <ShoppingCart className="w-10 h-10 text-green-600" />
            {qtdTotal > 0 && (
              <span className="absolute -top-2 -right-2 bg-green-500 text-white font-bold w-8 h-8 rounded-full flex items-center justify-center text-lg">{qtdTotal}</span>
            )}
          </button>
        </div>

        {/* Grid produtos */}
        <div className="flex-1 p-8 overflow-auto">
          <div className="grid grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6 max-w-screen-2xl mx-auto">
            {produtosFiltrados.map((p, idx) => (
              <motion.div
                key={p.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: idx * 0.04 }}
                className="bg-white rounded-3xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow"
              >
                <div className="relative aspect-square bg-gray-100">
                  <img src={p.imagem} alt={p.nome} className="w-full h-full object-cover" loading="lazy" onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }} />
                  <button
                    onClick={() => addCarrinho(p)}
                    className="absolute bottom-4 right-4 w-16 h-16 bg-green-500 hover:bg-green-600 text-white rounded-full flex items-center justify-center shadow-lg transition-colors"
                  >
                    <Plus className="w-8 h-8" />
                  </button>
                </div>
                <div className="p-6">
                  <h3 className="font-display text-2xl font-bold text-gray-800 mb-2">{p.nome}</h3>
                  <p className="font-mono text-3xl font-bold text-green-600">{p.preco.toFixed(2)} EUR</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Barra inferior com total */}
        {qtdTotal > 0 && (
          <motion.div
            initial={{ y: 100 }}
            animate={{ y: 0 }}
            className="h-28 bg-white border-t flex items-center justify-between px-10 shadow-lg"
          >
            <div>
              <p className="text-2xl text-gray-500">{qtdTotal} item(s) no carrinho</p>
              <p className="font-mono text-4xl font-bold text-green-600">{total.toFixed(2)} EUR</p>
            </div>
            <button onClick={() => setKv('carrinho')} className="h-20 px-16 bg-green-500 hover:bg-green-600 text-white text-3xl font-bold rounded-2xl flex items-center gap-4 transition-colors">
              Ver Carrinho <ArrowRight className="w-8 h-8" />
            </button>
          </motion.div>
        )}
      </div>
    );
  }

  // ===== CARRINHO =====
  if (kv === 'carrinho') {
    return (
      <div className="h-screen w-screen bg-gray-50 flex flex-col overflow-hidden">
        <div className="h-24 bg-white border-b flex items-center justify-between px-10">
          <button onClick={() => setKv('produtos')} className="text-3xl font-bold text-gray-400 hover:text-gray-600 flex items-center gap-2">
            <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" /></svg>
            Voltar
          </button>
          <h1 className="font-display text-5xl font-bold text-gray-800">Carrinho</h1>
          <button onClick={() => setCarrinhoLocal([])} className="text-2xl text-red-400 hover:text-red-600 flex items-center gap-2">
            <Trash2 className="w-6 h-6" /> Limpar
          </button>
        </div>

        <div className="flex-1 p-10 overflow-auto">
          {carrinhoLocal.length === 0 ? (
            <div className="text-center py-20">
              <ShoppingCart className="w-24 h-24 mx-auto text-gray-300 mb-6" />
              <p className="text-4xl text-gray-400 font-display font-bold">Carrinho vazio</p>
              <p className="text-2xl text-gray-300 mt-2">Adicione produtos primeiro</p>
              <button onClick={() => setKv('categorias')} className="mt-8 h-20 px-16 bg-green-500 text-white text-3xl font-bold rounded-2xl">
                Ir as Categorias
              </button>
            </div>
          ) : (
            <div className="max-w-4xl mx-auto space-y-4">
              {carrinhoLocal.map((item) => (
                <motion.div
                  key={item.produto.id}
                  layout
                  className="bg-white rounded-2xl p-6 shadow-sm flex items-center gap-6"
                >
                  <img src={item.produto.imagem} alt={item.produto.nome} className="w-24 h-24 rounded-xl object-cover bg-gray-100" onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }} />
                  <div className="flex-1">
                    <h3 className="font-display text-3xl font-bold text-gray-800">{item.produto.nome}</h3>
                    <p className="font-mono text-2xl text-green-600 font-bold">{item.produto.preco.toFixed(2)} EUR</p>
                  </div>
                  <div className="flex items-center gap-4">
                    <button onClick={() => updateQtd(item.produto.id, item.qtd - 1)} className="w-16 h-16 bg-gray-100 hover:bg-gray-200 rounded-full flex items-center justify-center">
                      <Minus className="w-8 h-8" />
                    </button>
                    <span className="font-mono text-4xl font-bold w-16 text-center">{item.qtd}</span>
                    <button onClick={() => updateQtd(item.produto.id, item.qtd + 1)} className="w-16 h-16 bg-green-100 hover:bg-green-200 text-green-600 rounded-full flex items-center justify-center">
                      <Plus className="w-8 h-8" />
                    </button>
                  </div>
                  <p className="font-mono text-3xl font-bold text-gray-800 w-40 text-right">{(item.produto.preco * item.qtd).toFixed(2)} EUR</p>
                </motion.div>
              ))}
            </div>
          )}
        </div>

        {carrinhoLocal.length > 0 && (
          <div className="h-36 bg-white border-t flex items-center justify-between px-10 shadow-lg">
            <div>
              <p className="text-2xl text-gray-500">Total</p>
              <p className="font-mono text-6xl font-bold text-green-600">{total.toFixed(2)} EUR</p>
            </div>
            <button onClick={processarPagamento} className="h-28 px-20 bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white text-4xl font-bold rounded-3xl shadow-xl flex items-center gap-6 transition-all">
              <CreditCard className="w-10 h-10" /> Pagar Agora
            </button>
          </div>
        )}
      </div>
    );
  }

  // ===== PAGAMENTO =====
  if (kv === 'pagamento') {
    return (
      <div className="h-screen w-screen bg-gradient-to-br from-green-500 to-emerald-600 flex flex-col items-center justify-center overflow-hidden relative">
        {/* Confetti */}
        <AnimatePresence>
          {confetti.map((c) => (
            <motion.div
              key={c.id}
              initial={{ y: -100, x: `${c.x}vw`, opacity: 1, rotate: 0 }}
              animate={{ y: '110vh', rotate: c.rot * 3 }}
              transition={{ duration: 3 + Math.random(), ease: 'easeIn' }}
              className="fixed top-0 w-4 h-4 z-50"
              style={{ backgroundColor: c.color, left: `${c.x}%`, borderRadius: Math.random() > 0.5 ? '50%' : '2px' }}
            />
          ))}
        </AnimatePresence>

        <AnimatePresence mode="wait">
          {payStep === 0 && (
            <motion.div key="s0" initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }} className="text-center">
              {/* Spinner duplo */}
              <div className="relative w-40 h-40 mx-auto mb-10">
                <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: 'linear' }} className="absolute inset-0 rounded-full border-8 border-white/30 border-t-white" />
                <motion.div animate={{ rotate: -360 }} transition={{ duration: 1.5, repeat: Infinity, ease: 'linear' }} className="absolute inset-4 rounded-full border-8 border-white/20 border-b-white" />
              </div>
              <h2 className="font-display text-6xl font-bold text-white mb-4">Processando...</h2>
              <p className="text-3xl text-white/80">Conectando com o banco</p>
            </motion.div>
          )}

          {payStep === 1 && (
            <motion.div key="s1" initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }} className="text-center">
              <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: 'spring' }} className="w-40 h-40 bg-white/20 rounded-full mx-auto mb-10 flex items-center justify-center">
                <QrCode className="w-20 h-20 text-white" />
              </motion.div>
              <h2 className="font-display text-6xl font-bold text-white mb-4">Verificando...</h2>
              <p className="text-3xl text-white/80">Validando pagamento</p>
            </motion.div>
          )}

          {payStep === 2 && (
            <motion.div key="s2" initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }} className="text-center">
              <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: 'spring', stiffness: 200 }} className="w-40 h-40 bg-white rounded-full mx-auto mb-10 flex items-center justify-center shadow-2xl">
                <Check className="w-24 h-24 text-green-500" strokeWidth={4} />
              </motion.div>
              <h2 className="font-display text-6xl font-bold text-white mb-4">Aprovado!</h2>
              <p className="text-3xl text-white/80">Pagamento confirmado</p>
            </motion.div>
          )}

          {payStep === 3 && (
            <motion.div key="s3" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center z-10">
              <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: 'spring', delay: 0.2 }} className="mb-8">
                <Sparkles className="w-24 h-24 text-yellow-300 mx-auto" />
              </motion.div>
              <motion.h1 initial={{ y: 50, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: 0.3 }} className="font-display text-8xl font-extrabold text-white mb-4 drop-shadow-lg">
                Obrigado!
              </motion.h1>
              <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }} className="text-4xl text-white/90 mb-4">
                Seu pedido foi confirmado
              </motion.p>
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.7 }} className="bg-white/20 backdrop-blur rounded-3xl p-8 inline-block">
                <p className="text-2xl text-white/80 mb-2">Numero do Pedido</p>
                <p className="font-mono text-9xl font-bold text-white">#{Math.floor(Math.random() * 900) + 100}</p>
              </motion.div>
              <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1 }} className="text-3xl text-white/70 mt-8">
                Aguarde, estamos preparando seu gelato!
              </motion.p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    );
  }

  return null;
}
