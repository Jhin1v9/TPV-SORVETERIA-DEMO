import { useState, useEffect } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { useStore } from '@/store/useStore';
import LoginPage from './pages/LoginPage';
import CardapioPage from './pages/CardapioPage';
import PagamentoPage from './pages/PagamentoPage';
import RastreamentoPage from './pages/RastreamentoPage';
import ConfigPage from './pages/ConfigPage';
import HeaderCliente from './components/HeaderCliente';
import CarrinhoDrawer from './components/CarrinhoDrawer';
import BottomNav from './components/BottomNav';

type ClienteView = 'cardapio' | 'carrinho' | 'pedidos' | 'config' | 'pagamento';

export default function ClienteApp() {
  const { usuario, notificacao, limparNotificacao, carrinho } = useStore();
  const [view, setView] = useState<ClienteView>('cardapio');

  // Notificacao de pedido pronto
  useEffect(() => {
    if (notificacao.tipo === 'pronto') {
      const timer = setTimeout(() => limparNotificacao(), 8000);
      return () => clearTimeout(timer);
    }
  }, [notificacao, limparNotificacao]);

  if (!usuario?.logado) {
    return <LoginPage />;
  }

  const totalItens = carrinho.reduce((s, i) => s + i.quantidade, 0);

  return (
    <div className="min-h-screen bg-tropicale-bg relative">
      {/* Notificacao amigavel flutuante */}
      <AnimatePresence>
        {notificacao.tipo === 'pronto' && (
          <motion.div
            initial={{ opacity: 0, y: -100, scale: 0.8 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -100, scale: 0.8 }}
            className="fixed top-4 left-4 right-4 z-[100] flex justify-center"
          >
            <div
              className="bg-gradient-to-r from-purple-500 to-indigo-600 text-white px-8 py-5 rounded-2xl shadow-2xl flex items-center gap-4 cursor-pointer"
              onClick={() => { limparNotificacao(); setView('pedidos'); }}
            >
              <span className="text-4xl">🍦</span>
              <div>
                <p className="text-xl font-bold">Seu sorvete ta pronto!</p>
                <p className="text-white/80">Vem buscar! Toque para ver</p>
              </div>
              <button
                onClick={(e) => { e.stopPropagation(); limparNotificacao(); }}
                className="ml-4 text-white/60 hover:text-white"
              >
                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header (apenas no cardapio) */}
      {view === 'cardapio' && <HeaderCliente onVerPedidos={() => setView('pedidos')} />}

      {/* Carrinho Drawer */}
      <CarrinhoDrawer onCheckout={() => setView('pagamento')} />

      {/* Content */}
      <main className={view === 'cardapio' ? '' : 'pt-0'}>
        <AnimatePresence mode="wait">
          {view === 'cardapio' && (
            <motion.div key="cardapio" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <CardapioPage />
            </motion.div>
          )}
          {view === 'carrinho' && (
            <motion.div key="carrinho" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <div className="max-w-lg mx-auto px-4 py-6">
                <h1 className="font-display text-2xl font-bold text-gray-800 mb-4">Carrinho</h1>
                {/* Reutiliza o carrinho do drawer */}
                <p className="text-gray-500">Use o icone do carrinho no topo ou na barra inferior.</p>
              </div>
            </motion.div>
          )}
          {view === 'pedidos' && (
            <motion.div key="pedidos" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <RastreamentoPage onBack={() => setView('cardapio')} />
            </motion.div>
          )}
          {view === 'config' && (
            <motion.div key="config" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <ConfigPage />
            </motion.div>
          )}
          {view === 'pagamento' && (
            <motion.div key="pagamento" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <PagamentoPage
                onComplete={() => setView('pedidos')}
                onBack={() => setView('cardapio')}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Bottom Navigation */}
      <BottomNav
        active={view === 'pagamento' ? 'carrinho' : view}
        onNavigate={(page) => {
          if (page === 'carrinho') {
            useStore.getState().abrirCarrinho();
          } else {
            setView(page as ClienteView);
          }
        }}
        cartCount={totalItens}
      />
    </div>
  );
}
