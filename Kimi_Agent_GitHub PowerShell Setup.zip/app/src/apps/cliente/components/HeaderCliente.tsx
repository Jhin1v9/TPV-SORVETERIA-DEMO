import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useStore } from '@/store/useStore';
import { Search, ShoppingCart, User, LogOut, X, ChevronLeft, Receipt } from 'lucide-react';

interface HeaderClienteProps {
  onVerPedidos?: () => void;
}

export default function HeaderCliente({ onVerPedidos }: HeaderClienteProps) {
  const { usuario, logout, carrinho, toggleCarrinho, busca, setBusca, setView } = useStore();
  const [menuOpen, setMenuOpen] = useState(false);
  const totalItens = carrinho.reduce((s, i) => s + i.quantidade, 0);

  return (
    <header className="sticky top-0 z-50 glass border-b border-gray-100">
      <div className="max-w-5xl mx-auto px-4 h-16 flex items-center justify-between gap-3">
        {/* Back button (mobile) + Logo */}
        <div className="flex items-center gap-3">
          <button onClick={() => setView('selector')} className="lg:hidden p-2 -ml-2 text-gray-400 hover:text-gray-600">
            <ChevronLeft className="w-5 h-5" />
          </button>
          <button onClick={() => setView('selector')} className="flex items-center gap-2.5 hover:opacity-80 transition-opacity">
            <div className="w-9 h-9 bg-gradient-to-br from-green-400 to-emerald-600 rounded-xl flex items-center justify-center">
              <svg viewBox="0 0 24 24" className="w-5 h-5" fill="none">
                <path d="M12 5 C7 5, 4 9, 4 13 C4 18, 7 20, 12 20 C17 20, 20 18, 20 13 C20 9, 17 5, 12 5Z" fill="white" opacity="0.9"/>
                <path d="M8 12 Q12 19 16 12" stroke="#3E2723" strokeWidth="2" fill="none" strokeLinecap="round"/>
              </svg>
            </div>
            <span className="font-display font-bold text-lg hidden sm:block">Tropicale</span>
          </button>
        </div>

        {/* Search */}
        <div className="flex-1 max-w-md relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            type="text"
            value={busca}
            onChange={(e) => setBusca(e.target.value)}
            placeholder="Buscar gelats..."
            className="w-full h-10 pl-10 pr-4 rounded-btn bg-gray-100 border-0 focus:bg-white focus:ring-2 focus:ring-green-100 outline-none text-sm transition-all"
          />
          {busca && (
            <button onClick={() => setBusca('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Right actions */}
        <div className="flex items-center gap-2">
          {onVerPedidos && (
            <button onClick={onVerPedidos} className="hidden sm:flex items-center gap-1.5 h-10 px-3 rounded-btn bg-gray-100 hover:bg-gray-200 text-gray-600 text-sm font-medium transition-colors">
              <Receipt className="w-4 h-4" />
              <span className="hidden md:inline">Meus pedidos</span>
            </button>
          )}

          <button
            onClick={toggleCarrinho}
            className="relative h-10 w-10 rounded-btn bg-green-50 hover:bg-green-100 flex items-center justify-center text-green-600 transition-colors"
          >
            <ShoppingCart className="w-5 h-5" />
            {totalItens > 0 && (
              <motion.span
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className="absolute -top-1 -right-1 bg-green-500 text-white text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center"
              >
                {totalItens}
              </motion.span>
            )}
          </button>

          <div className="relative">
            <button
              onClick={() => setMenuOpen(!menuOpen)}
              className="h-10 w-10 rounded-btn bg-gray-100 hover:bg-gray-200 flex items-center justify-center text-gray-600 transition-colors"
            >
              <User className="w-5 h-5" />
            </button>
            <AnimatePresence>
              {menuOpen && (
                <>
                  <div className="fixed inset-0 z-40" onClick={() => setMenuOpen(false)} />
                  <motion.div
                    initial={{ opacity: 0, y: -10, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: -10, scale: 0.95 }}
                    className="absolute right-0 top-12 w-56 bg-white rounded-card shadow-lg border border-gray-100 z-50 overflow-hidden"
                  >
                    <div className="px-4 py-3 border-b border-gray-50">
                      <p className="font-medium text-sm text-gray-800 truncate">{usuario?.nome}</p>
                      <p className="text-xs text-gray-400 truncate">{usuario?.email}</p>
                    </div>
                    {onVerPedidos && (
                      <button
                        onClick={() => { onVerPedidos(); setMenuOpen(false); }}
                        className="w-full px-4 py-2.5 text-left text-sm text-gray-600 hover:bg-gray-50 flex items-center gap-2 sm:hidden"
                      >
                        <Receipt className="w-4 h-4" />
                        Meus pedidos
                      </button>
                    )}
                    <button
                      onClick={() => { logout(); setMenuOpen(false); }}
                      className="w-full px-4 py-2.5 text-left text-sm text-red-500 hover:bg-red-50 flex items-center gap-2"
                    >
                      <LogOut className="w-4 h-4" />
                      Sair
                    </button>
                  </motion.div>
                </>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </header>
  );
}
