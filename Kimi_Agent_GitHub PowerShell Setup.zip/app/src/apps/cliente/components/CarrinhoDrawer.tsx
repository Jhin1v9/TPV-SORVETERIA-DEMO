import { motion, AnimatePresence } from 'framer-motion';
import { useStore } from '@/store/useStore';
import { X, Plus, Minus, ShoppingBag, Trash2, ArrowRight } from 'lucide-react';

interface CarrinhoDrawerProps {
  onCheckout: () => void;
}

export default function CarrinhoDrawer({ onCheckout }: CarrinhoDrawerProps) {
  const { carrinho, carrinhoAberto, fecharCarrinho, removeItem, updateQuantidade, totalCarrinho } = useStore();
  const total = totalCarrinho();

  return (
    <AnimatePresence>
      {carrinhoAberto && (
        <>
          {/* Overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={fecharCarrinho}
            className="fixed inset-0 bg-black/40 z-50"
          />
          {/* Drawer */}
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed right-0 top-0 h-full w-full max-w-md bg-white z-50 shadow-2xl flex flex-col"
          >
            {/* Header */}
            <div className="flex items-center justify-between p-4 border-b border-gray-100">
              <div className="flex items-center gap-2">
                <ShoppingBag className="w-5 h-5 text-green-600" />
                <h2 className="font-display font-bold text-lg">Carrinho</h2>
                <span className="bg-green-100 text-green-700 text-xs font-bold px-2 py-0.5 rounded-full">
                  {carrinho.reduce((s, i) => s + i.quantidade, 0)}
                </span>
              </div>
              <button onClick={fecharCarrinho} className="w-9 h-9 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center transition-colors">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Items */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {carrinho.length === 0 ? (
                <div className="text-center py-16">
                  <ShoppingBag className="w-16 h-16 mx-auto text-gray-200 mb-4" />
                  <p className="text-gray-400 font-medium">Seu carrinho esta vazio</p>
                  <p className="text-gray-300 text-sm mt-1">Adicione produtos do cardapio</p>
                </div>
              ) : (
                carrinho.map((item) => (
                  <motion.div
                    key={item.produto.id}
                    layout
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, x: -50 }}
                    className="flex gap-3 bg-gray-50 rounded-btn p-3"
                  >
                    <img
                      src={item.produto.imagem}
                      alt={item.produto.nome}
                      className="w-16 h-16 rounded-lg object-cover bg-gray-200 flex-shrink-0"
                      loading="lazy"
                      onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
                    />
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium text-sm text-gray-800 truncate">{item.produto.nome}</h4>
                      <p className="font-mono text-green-600 text-sm font-bold mt-0.5">
                        {(item.produto.preco * item.quantidade).toFixed(2)} &euro;
                      </p>
                      <div className="flex items-center gap-2 mt-1.5">
                        <button
                          onClick={() => updateQuantidade(item.produto.id, item.quantidade - 1)}
                          className="w-7 h-7 rounded-full bg-white border border-gray-200 flex items-center justify-center hover:bg-gray-100"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="font-mono font-bold text-sm w-6 text-center">{item.quantidade}</span>
                        <button
                          onClick={() => updateQuantidade(item.produto.id, item.quantidade + 1)}
                          className="w-7 h-7 rounded-full bg-white border border-gray-200 flex items-center justify-center hover:bg-gray-100"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                        <button
                          onClick={() => removeItem(item.produto.id)}
                          className="ml-auto w-7 h-7 rounded-full bg-red-50 text-red-400 flex items-center justify-center hover:bg-red-100"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  </motion.div>
                ))
              )}
            </div>

            {/* Footer */}
            {carrinho.length > 0 && (
              <div className="p-4 border-t border-gray-100 bg-gray-50">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-gray-500">Subtotal</span>
                  <span className="font-mono font-bold text-gray-800">{total.toFixed(2)} &euro;</span>
                </div>
                <div className="flex items-center justify-between mb-4">
                  <span className="text-gray-500">Envio</span>
                  <span className="badge-green">Gratis</span>
                </div>
                <div className="flex items-center justify-between mb-4 pt-3 border-t border-gray-200">
                  <span className="font-bold text-gray-800">Total</span>
                  <span className="font-mono font-bold text-xl text-green-600">{total.toFixed(2)} &euro;</span>
                </div>
                <motion.button
                  onClick={() => { fecharCarrinho(); onCheckout(); }}
                  whileTap={{ scale: 0.98 }}
                  className="w-full h-14 btn-primary rounded-btn flex items-center justify-center gap-2 text-base font-bold"
                >
                  Finalizar pedido
                  <ArrowRight className="w-5 h-5" />
                </motion.button>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
