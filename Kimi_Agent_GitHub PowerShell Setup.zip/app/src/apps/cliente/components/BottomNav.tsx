import { motion } from 'framer-motion';
import { Home, ShoppingBag, ReceiptText, Settings } from 'lucide-react';

interface BottomNavProps {
  active: string;
  onNavigate: (page: string) => void;
  cartCount: number;
}

const items = [
  { id: 'cardapio', label: 'Cardápio', icon: Home },
  { id: 'carrinho', label: 'Carrinho', icon: ShoppingBag, showBadge: true },
  { id: 'pedidos', label: 'Pedidos', icon: ReceiptText },
  { id: 'config', label: 'Ajustes', icon: Settings },
];

export default function BottomNav({ active, onNavigate, cartCount }: BottomNavProps) {
  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white/90 backdrop-blur-lg border-t border-gray-100 z-50">
      <div className="max-w-lg mx-auto flex justify-around py-1">
        {items.map((item) => {
          const Icon = item.icon;
          const isActive = active === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className="relative flex flex-col items-center gap-0.5 px-4 py-2 rounded-xl transition-colors"
            >
              <div className="relative">
                <Icon className={`w-6 h-6 transition-colors ${isActive ? 'text-green-600' : 'text-gray-400'}`} />
                {item.showBadge && cartCount > 0 && (
                  <motion.span
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="absolute -top-2 -right-2.5 bg-green-500 text-white text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center"
                  >
                    {cartCount}
                  </motion.span>
                )}
              </div>
              <span className={`text-[11px] font-medium ${isActive ? 'text-green-600' : 'text-gray-400'}`}>
                {item.label}
              </span>
              {isActive && (
                <motion.div
                  layoutId="bottomNavIndicator"
                  className="absolute -bottom-1 w-8 h-0.5 bg-green-500 rounded-full"
                />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
}
