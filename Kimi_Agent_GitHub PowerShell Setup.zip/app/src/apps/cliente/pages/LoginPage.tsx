import { useState } from 'react';
import { motion } from 'framer-motion';
import { useStore } from '@/store/useStore';
import { LogIn, UserPlus, ArrowLeft, Eye, EyeOff } from 'lucide-react';

type AuthMode = 'login' | 'register';

export default function LoginPage() {
  const { login, setView } = useStore();
  const [mode, setMode] = useState<AuthMode>('login');
  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');
  const [telefone, setTelefone] = useState('');
  const [senha, setSenha] = useState('');
  const [mostrarSenha, setMostrarSenha] = useState(false);
  const [erro, setErro] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErro('');
    if (mode === 'register') {
      if (!nome.trim() || !email.trim() || !telefone.trim()) {
        setErro('Todos os campos sao obrigatorios');
        return;
      }
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        setErro('Email invalido');
        return;
      }
    } else {
      if (!email.trim() || !senha.trim()) {
        setErro('Email e senha sao obrigatorios');
        return;
      }
    }
    login(nome || 'Cliente', email, telefone || undefined);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md"
      >
        <button
          onClick={() => setView('selector')}
          className="flex items-center gap-2 text-gray-500 hover:text-gray-700 mb-6 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span className="text-sm">Voltar</span>
        </button>

        {/* Logo */}
        <div className="text-center mb-8">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: 'spring', delay: 0.2 }}
            className="w-20 h-20 mx-auto mb-4 bg-gradient-to-br from-green-400 to-emerald-600 rounded-2xl flex items-center justify-center shadow-lg"
          >
            <svg viewBox="0 0 40 40" className="w-12 h-12" fill="none">
              <path d="M20 8 C12 8, 8 14, 8 20 C8 28, 12 32, 20 32 C28 32, 32 28, 32 20 C32 14, 28 8, 20 8Z" fill="white" opacity="0.9"/>
              <path d="M14 18 Q20 30 26 18" stroke="#3E2723" strokeWidth="2.5" fill="none" strokeLinecap="round"/>
              <circle cx="16" cy="15" r="1.5" fill="#4CAF50"/>
              <circle cx="24" cy="14" r="1.5" fill="#8D6E63"/>
            </svg>
          </motion.div>
          <h1 className="font-display text-3xl font-bold text-gray-800">Tropicale</h1>
          <p className="text-gray-400 text-sm mt-1">Gelats Artesanais</p>
        </div>

        {/* Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-white/80 backdrop-blur-lg rounded-card shadow-card p-8"
        >
          {/* Tabs */}
          <div className="flex bg-gray-100 rounded-btn p-1 mb-6">
            <button
              onClick={() => { setMode('login'); setErro(''); }}
              className={`flex-1 py-2.5 rounded-btn text-sm font-semibold transition-all ${
                mode === 'login' ? 'bg-white text-green-600 shadow-sm' : 'text-gray-400'
              }`}
            >
              Entrar
            </button>
            <button
              onClick={() => { setMode('register'); setErro(''); }}
              className={`flex-1 py-2.5 rounded-btn text-sm font-semibold transition-all ${
                mode === 'register' ? 'bg-white text-green-600 shadow-sm' : 'text-gray-400'
              }`}
            >
              Cadastro
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {mode === 'register' && (
              <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }}>
                <label className="block text-xs font-medium text-gray-500 mb-1.5">Nome Completo</label>
                <input
                  type="text"
                  value={nome}
                  onChange={(e) => setNome(e.target.value)}
                  placeholder="Seu nome"
                  className="w-full h-12 px-4 rounded-btn border border-gray-200 focus:border-green-400 focus:ring-2 focus:ring-green-100 outline-none transition-all text-sm"
                />
              </motion.div>
            )}

            <div>
              <label className="block text-xs font-medium text-gray-500 mb-1.5">Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="seu@email.com"
                className="w-full h-12 px-4 rounded-btn border border-gray-200 focus:border-green-400 focus:ring-2 focus:ring-green-100 outline-none transition-all text-sm"
              />
            </div>

            {mode === 'register' && (
              <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }}>
                <label className="block text-xs font-medium text-gray-500 mb-1.5">Telefone</label>
                <input
                  type="tel"
                  value={telefone}
                  onChange={(e) => setTelefone(e.target.value.replace(/\D/g, '').slice(0, 11))}
                  placeholder="(XX) XXXXX-XXXX"
                  className="w-full h-12 px-4 rounded-btn border border-gray-200 focus:border-green-400 focus:ring-2 focus:ring-green-100 outline-none transition-all text-sm"
                />
              </motion.div>
            )}

            <div className="relative">
              <label className="block text-xs font-medium text-gray-500 mb-1.5">Senha</label>
              <input
                type={mostrarSenha ? 'text' : 'password'}
                value={senha}
                onChange={(e) => setSenha(e.target.value)}
                placeholder="••••••"
                className="w-full h-12 px-4 pr-12 rounded-btn border border-gray-200 focus:border-green-400 focus:ring-2 focus:ring-green-100 outline-none transition-all text-sm"
              />
              <button
                type="button"
                onClick={() => setMostrarSenha(!mostrarSenha)}
                className="absolute right-3 top-[30px] text-gray-400 hover:text-gray-600"
              >
                {mostrarSenha ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            </div>

            {erro && (
              <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-red-500 text-sm bg-red-50 px-3 py-2 rounded-lg">
                {erro}
              </motion.p>
            )}

            <motion.button
              type="submit"
              whileTap={{ scale: 0.98 }}
              className="w-full h-14 btn-primary rounded-btn flex items-center justify-center gap-2 text-base"
            >
              {mode === 'login' ? <LogIn className="w-5 h-5" /> : <UserPlus className="w-5 h-5" />}
              {mode === 'login' ? 'Entrar' : 'Cadastrar'}
            </motion.button>
          </form>

          <p className="text-center text-gray-400 text-xs mt-4">Demo: preencha qualquer email e senha</p>
        </motion.div>
      </motion.div>
    </div>
  );
}
