import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { useStore } from '@/store/useStore';
import { Package, ChefHat, CheckCircle, Truck, RotateCcw, Clock, ArrowLeft, MapPin } from 'lucide-react';

const etapas = [
  { key: 'pendente', label: 'Pedido recebido', icon: Package, desc: 'Seu pedido foi confirmado' },
  { key: 'preparando', label: 'Em preparacao', icon: ChefHat, desc: 'Estamos preparando seu gelato' },
  { key: 'listo', label: 'Pronto', icon: CheckCircle, desc: 'Seu pedido esta pronto' },
  { key: 'entregado', label: 'Entregue', icon: Truck, desc: 'Entregue com sucesso' },
] as const;

interface RastreamentoPageProps {
  onBack: () => void;
}

export default function RastreamentoPage({ onBack }: RastreamentoPageProps) {
  const { pedidosCliente, atualizarEstadoPedido } = useStore();
  const [simulando, setSimulando] = useState<string | null>(null);

  // Simular progresso para demo
  useEffect(() => {
    const interval = setInterval(() => {
      pedidosCliente.forEach((p) => {
        if (p.estado === 'pendente' && Math.random() > 0.95) {
          atualizarEstadoPedido(p.id, 'preparando');
        } else if (p.estado === 'preparando' && Math.random() > 0.97) {
          atualizarEstadoPedido(p.id, 'listo');
        }
      });
    }, 3000);
    return () => clearInterval(interval);
  }, [pedidosCliente, atualizarEstadoPedido]);

  const simularEntrega = (id: string) => {
    setSimulando(id);
    setTimeout(() => {
      atualizarEstadoPedido(id, 'entregado');
      setSimulando(null);
    }, 1500);
  };

  const pedidosRecentes = [...pedidosCliente].sort((a, b) => b.timestamp - a.timestamp);

  if (pedidosRecentes.length === 0) {
    return (
      <div className="min-h-screen bg-tropicale-bg flex items-center justify-center">
        <div className="text-center">
          <Package className="w-16 h-16 mx-auto text-gray-300 mb-4" />
          <h2 className="font-display text-xl font-bold text-gray-700 mb-2">Nenhum pedido ainda</h2>
          <p className="text-gray-400 mb-6">Faca seu primeiro pedido para acompanhar aqui</p>
          <button onClick={onBack} className="h-12 px-6 btn-primary rounded-btn">
            Voltar ao cardapio
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-tropicale-bg">
      <div className="max-w-lg mx-auto px-4 py-6">
        <button onClick={onBack} className="flex items-center gap-2 text-gray-500 hover:text-gray-700 mb-6">
          <ArrowLeft className="w-5 h-5" />
          <span>Voltar</span>
        </button>

        <h1 className="font-display text-2xl font-bold text-gray-800 mb-6">Meus pedidos</h1>

        <div className="space-y-6">
          {pedidosRecentes.map((pedido) => {
            const idxEstado = etapas.findIndex((e) => e.key === pedido.estado);
            const progresso = ((idxEstado + 1) / etapas.length) * 100;

            return (
              <motion.div
                key={pedido.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-white rounded-card shadow-card overflow-hidden"
              >
                {/* Header do pedido */}
                <div className="p-4 border-b border-gray-50 flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-gray-800">#{pedido.id.slice(-6).toUpperCase()}</span>
                      <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                        pedido.estado === 'entregado' ? 'bg-green-100 text-green-600' :
                        pedido.estado === 'cancelado' ? 'bg-red-100 text-red-600' :
                        'bg-blue-100 text-blue-600'
                      }`}>
                        {pedido.estado === 'pendente' ? 'Pendente' :
                         pedido.estado === 'preparando' ? 'Preparando' :
                         pedido.estado === 'listo' ? 'Pronto' :
                         pedido.estado === 'entregado' ? 'Entregue' : 'Cancelado'}
                      </span>
                    </div>
                    <p className="text-xs text-gray-400 mt-1">
                      {new Date(pedido.timestamp).toLocaleString('pt-BR')}
                    </p>
                  </div>
                  <span className="font-mono font-bold text-green-600">{pedido.total.toFixed(2)} &euro;</span>
                </div>

                {/* Itens */}
                <div className="px-4 py-3 border-b border-gray-50">
                  {pedido.itens.map((item) => (
                    <div key={item.produto.id} className="flex items-center gap-2 text-sm text-gray-600 py-0.5">
                      <span className="font-medium">{item.quantidade}x</span>
                      <span>{item.produto.nome}</span>
                    </div>
                  ))}
                </div>

                {/* Timeline */}
                <div className="p-4">
                  {/* Barra de progresso */}
                  <div className="relative h-2 bg-gray-100 rounded-full mb-4 overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${progresso}%` }}
                      transition={{ duration: 1, ease: 'easeOut' }}
                      className="absolute inset-y-0 left-0 bg-gradient-to-r from-green-400 to-emerald-500 rounded-full"
                    />
                  </div>

                  {/* Etapas */}
                  <div className="grid grid-cols-4 gap-2">
                    {etapas.map((etapa, i) => {
                      const Icon = etapa.icon;
                      const ativo = i <= idxEstado;
                      const atual = i === idxEstado;
                      return (
                        <div key={etapa.key} className="flex flex-col items-center text-center">
                          <div className={`w-10 h-10 rounded-full flex items-center justify-center mb-1 transition-all ${
                            ativo ? 'bg-green-500 text-white shadow-lg' :
                            'bg-gray-100 text-gray-300'
                          } ${atual ? 'ring-4 ring-green-100 scale-110' : ''}`}>
                            <Icon className="w-5 h-5" />
                          </div>
                          <span className={`text-[10px] font-medium leading-tight ${ativo ? 'text-green-600' : 'text-gray-300'}`}>
                            {etapa.label}
                          </span>
                        </div>
                      );
                    })}
                  </div>

                  {/* Botao simular entrega (demo) */}
                  {pedido.estado === 'listo' && (
                    <motion.button
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      onClick={() => simularEntrega(pedido.id)}
                      disabled={simulando === pedido.id}
                      className="w-full mt-4 h-10 bg-green-50 text-green-600 rounded-btn text-sm font-medium hover:bg-green-100 transition-colors flex items-center justify-center gap-2"
                    >
                      {simulando === pedido.id ? (
                        <><RotateCcw className="w-4 h-4 animate-spin" /> Processando...</>
                      ) : (
                        <><CheckCircle className="w-4 h-4" /> Marcar como entregue</>
                      )}
                    </motion.button>
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
