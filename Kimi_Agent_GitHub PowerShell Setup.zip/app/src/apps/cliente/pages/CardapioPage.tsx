import { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { useStore } from '@/store/useStore';
import { PRODUTOS, CATEGORIAS } from '@/data/cardapio';
import { Plus, Minus, Check } from 'lucide-react';

export default function CardapioPage() {
  const { categoriaAtiva, setCategoriaAtiva, busca, addItem, abrirCarrinho } = useStore();
  const [addingId, setAddingId] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  const produtosFiltrados = PRODUTOS.filter((p) => {
    const matchCat = categoriaAtiva === 'todos' || p.categoria === categoriaAtiva;
    const matchBusca = !busca || p.nome.toLowerCase().includes(busca.toLowerCase());
    return matchCat && matchBusca && p.emEstoque;
  });

  const handleAdd = (produto: typeof PRODUTOS[0]) => {
    addItem({ produto, quantidade: 1 });
    setAddingId(produto.id);
    setTimeout(() => setAddingId(null), 800);
    abrirCarrinho();
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-6">
      {/* Categorias scroll horizontal */}
      <div className="sticky top-16 z-40 bg-tropicale-bg/95 backdrop-blur-sm py-3 -mx-4 px-4 mb-4">
        <div ref={scrollRef} className="flex gap-2 overflow-x-auto no-scrollbar snap-x snap-mandatory">
          {CATEGORIAS.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setCategoriaAtiva(cat.id)}
              className={`flex-shrink-0 snap-start flex items-center gap-2 px-4 py-2.5 rounded-pill text-sm font-medium transition-all ${
                categoriaAtiva === cat.id
                  ? 'bg-green-500 text-white shadow-btn'
                  : 'bg-white text-gray-600 border border-gray-200 hover:border-green-300'
              }`}
            >
              <span>{cat.emoji}</span>
              <span className="whitespace-nowrap">{cat.nome}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Resultado */}
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-display text-lg font-semibold text-gray-700">
          {CATEGORIAS.find((c) => c.id === categoriaAtiva)?.nome || 'Todos'}
        </h2>
        <span className="text-sm text-gray-400">{produtosFiltrados.length} produtos</span>
      </div>

      {/* Grid produtos */}
      {produtosFiltrados.length === 0 ? (
        <div className="text-center py-20">
          <p className="text-gray-400 text-lg">Nenhum produto encontrado</p>
          <p className="text-gray-300 text-sm mt-1">Tente outra busca ou categoria</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
          {produtosFiltrados.map((prod, idx) => (
            <motion.div
              key={prod.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.03 }}
              className="card-ice-hover overflow-hidden group"
            >
              {/* Imagem */}
              <div className="relative aspect-square overflow-hidden bg-gray-100">
                <img
                  src={prod.imagem}
                  alt={prod.nome}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  loading="lazy"
                  onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
                />
                {/* Overlay de adicionado */}
                {addingId === prod.id && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="absolute inset-0 bg-green-500/80 flex items-center justify-center"
                  >
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      className="w-12 h-12 bg-white rounded-full flex items-center justify-center"
                    >
                      <Check className="w-6 h-6 text-green-500" />
                    </motion.div>
                  </motion.div>
                )}
                {/* Botao add */}
                <motion.button
                  onClick={() => handleAdd(prod)}
                  whileTap={{ scale: 0.9 }}
                  className="absolute bottom-2 right-2 w-9 h-9 bg-green-500 hover:bg-green-600 text-white rounded-full flex items-center justify-center shadow-lg opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <Plus className="w-5 h-5" />
                </motion.button>
              </div>

              {/* Info */}
              <div className="p-3">
                <h3 className="font-medium text-sm text-gray-800 leading-tight line-clamp-2 min-h-[2.5rem]">{prod.nome}</h3>
                <div className="flex items-center justify-between mt-2">
                  <span className="font-mono font-bold text-green-600 text-sm">{prod.preco.toFixed(2)} &euro;</span>
                  <button
                    onClick={() => handleAdd(prod)}
                    className="sm:hidden w-8 h-8 bg-green-50 text-green-600 rounded-full flex items-center justify-center"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
