import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useStore } from '@/store/useStore';
import {
  User, CreditCard, Clock, AlertTriangle, LogOut, CheckCircle,
  ChevronRight, Moon, Sun, Smartphone
} from 'lucide-react';

const ALERGENOS = ['Gluten', 'Lactosa', 'Frutos secos', 'Soja', 'Ovos', 'Marisco'];

export default function ConfigPage() {
  const { usuario, logout, configuracoes, toggleAlergeno, setTema, pedidosCliente } = useStore();
  const [perfil, setPerfil] = useState({ nome: usuario?.nome || '', telefone: usuario?.telefone || '', email: usuario?.email || '' });
  const [saved, setSaved] = useState(false);

  // Carregar perfil
  useEffect(() => {
    if (usuario) {
      setPerfil({ nome: usuario.nome || '', telefone: usuario.telefone || '', email: usuario.email || '' });
    }
  }, [usuario]);

  const handleSalvar = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  // Historico de pedidos
  const historico = [...pedidosCliente].sort((a, b) => b.timestamp - a.timestamp);

  const statusLabels: Record<string, { label: string; color: string }> = {
    pendente: { label: 'Pendente', color: 'bg-blue-100 text-blue-700' },
    preparando: { label: 'Preparando', color: 'bg-orange-100 text-orange-700' },
    listo: { label: 'Pronto', color: 'bg-green-100 text-green-700' },
    entregado: { label: 'Entregue', color: 'bg-gray-100 text-gray-500' },
    cancelado: { label: 'Cancelado', color: 'bg-red-100 text-red-500' },
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      {/* Header */}
      <div className="bg-white p-6 border-b border-gray-100 sticky top-0 z-10">
        <h1 className="font-display text-2xl font-bold text-gray-800">Configuracoes</h1>
      </div>

      <div className="p-4 space-y-4 max-w-lg mx-auto">

        {/* Notificacao salvo */}
        {saved && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="bg-green-100 text-green-700 rounded-xl px-4 py-3 flex items-center gap-2"
          >
            <CheckCircle className="w-5 h-5" />
            Alteracoes salvas com sucesso!
          </motion.div>
        )}

        {/* Perfil */}
        <section className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
              <User className="w-6 h-6 text-green-600" />
            </div>
            <h2 className="font-display text-lg font-bold text-gray-800">Meu Perfil</h2>
          </div>

          <div className="space-y-3">
            <div>
              <label className="block text-sm font-medium text-gray-500 mb-1">Nome completo</label>
              <input
                type="text"
                value={perfil.nome}
                onChange={(e) => setPerfil({ ...perfil, nome: e.target.value })}
                className="w-full h-12 px-4 rounded-xl border border-gray-200 focus:border-green-400 focus:ring-2 focus:ring-green-100 outline-none transition-all"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-500 mb-1">Telefone</label>
              <input
                type="tel"
                value={perfil.telefone}
                onChange={(e) => setPerfil({ ...perfil, telefone: e.target.value })}
                className="w-full h-12 px-4 rounded-xl border border-gray-200 focus:border-green-400 focus:ring-2 focus:ring-green-100 outline-none transition-all"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-500 mb-1">Email</label>
              <input
                type="email"
                value={perfil.email}
                onChange={(e) => setPerfil({ ...perfil, email: e.target.value })}
                className="w-full h-12 px-4 rounded-xl border border-gray-200 focus:border-green-400 focus:ring-2 focus:ring-green-100 outline-none transition-all"
              />
            </div>
          </div>
        </section>

        {/* Alergenos */}
        <section className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
              <AlertTriangle className="w-6 h-6 text-orange-600" />
            </div>
            <div>
              <h2 className="font-display text-lg font-bold text-gray-800">Alergenos</h2>
              <p className="text-xs text-gray-400">Selecione suas restricoes alimentares</p>
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            {ALERGENOS.map((alergeno) => {
              const ativo = configuracoes.alergenos.includes(alergeno);
              return (
                <button
                  key={alergeno}
                  onClick={() => toggleAlergeno(alergeno)}
                  className={`px-4 py-2.5 rounded-full border-2 font-medium text-sm transition-all ${
                    ativo
                      ? 'bg-red-500 text-white border-red-500'
                      : 'bg-white text-gray-600 border-gray-200 hover:border-gray-300'
                  }`}
                >
                  {alergeno}
                </button>
              );
            })}
          </div>
        </section>

        {/* Metodos de Pagamento (mock) */}
        <section className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                <CreditCard className="w-6 h-6 text-blue-600" />
              </div>
              <h2 className="font-display text-lg font-bold text-gray-800">Pagamentos</h2>
            </div>
          </div>

          <div className="space-y-3">
            <div className="p-4 rounded-xl border-2 border-green-500 bg-green-50 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Smartphone className="w-6 h-6 text-green-600" />
                <div>
                  <p className="font-medium text-gray-800">Bizum</p>
                  <p className="text-sm text-gray-500">**** 1234</p>
                </div>
              </div>
              <span className="bg-green-500 text-white text-xs px-2 py-1 rounded-full">Padrao</span>
            </div>
            <button className="w-full p-4 rounded-xl border-2 border-dashed border-gray-200 text-gray-400 hover:border-gray-300 hover:text-gray-500 transition-colors text-sm font-medium">
              + Adicionar metodo de pagamento
            </button>
          </div>
        </section>

        {/* Tema */}
        <section className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                {configuracoes.tema === 'escuro' ? (
                  <Moon className="w-6 h-6 text-purple-600" />
                ) : (
                  <Sun className="w-6 h-6 text-orange-500" />
                )}
              </div>
              <h2 className="font-display text-lg font-bold text-gray-800">Tema</h2>
            </div>
            <div className="flex bg-gray-100 rounded-lg p-1">
              <button
                onClick={() => setTema('claro')}
                className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
                  configuracoes.tema === 'claro' ? 'bg-white text-gray-800 shadow-sm' : 'text-gray-400'
                }`}
              >
                Claro
              </button>
              <button
                onClick={() => setTema('escuro')}
                className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
                  configuracoes.tema === 'escuro' ? 'bg-white text-gray-800 shadow-sm' : 'text-gray-400'
                }`}
              >
                Escuro
              </button>
            </div>
          </div>
        </section>

        {/* Historico */}
        <section className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-indigo-100 rounded-full flex items-center justify-center">
              <Clock className="w-6 h-6 text-indigo-600" />
            </div>
            <h2 className="font-display text-lg font-bold text-gray-800">Historico de Pedidos</h2>
          </div>

          <div className="space-y-3">
            {historico.length === 0 ? (
              <p className="text-gray-400 text-center py-6">Voce ainda nao fez nenhum pedido</p>
            ) : (
              historico.map((pedido) => {
                const st = statusLabels[pedido.estado] || statusLabels.pendente;
                return (
                  <div key={pedido.id} className="p-4 bg-gray-50 rounded-xl">
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <p className="font-mono font-bold text-gray-800">#{pedido.id.slice(-6).toUpperCase()}</p>
                        <p className="text-xs text-gray-400">{new Date(pedido.timestamp).toLocaleDateString('pt-BR')}</p>
                      </div>
                      <span className={`text-xs px-2 py-1 rounded-full ${st.color}`}>{st.label}</span>
                    </div>
                    <p className="text-sm text-gray-600">{pedido.itens.map((i) => `${i.quantidade}x ${i.produto.nome}`).join(', ')}</p>
                    <p className="font-mono font-bold text-green-600 mt-1">{pedido.total.toFixed(2)} EUR</p>
                  </div>
                );
              })
            )}
          </div>
        </section>

        {/* Salvar + Sair */}
        <button onClick={handleSalvar} className="w-full h-14 btn-primary rounded-btn font-bold">
          Salvar Alteracoes
        </button>

        <button
          onClick={() => { logout(); }}
          className="w-full h-14 bg-red-50 text-red-600 rounded-btn font-bold border-2 border-red-200 hover:bg-red-100 transition-colors flex items-center justify-center gap-2"
        >
          <LogOut className="w-5 h-5" /> Sair da Conta
        </button>
      </div>
    </div>
  );
}
