import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useStore } from '@/store/useStore';
import { Check, CreditCard, QrCode, ArrowLeft, Sparkles } from 'lucide-react';

type PaymentStep = 'form' | 'processing' | 'success';

interface PagamentoPageProps {
  onComplete: () => void;
  onBack: () => void;
}

export default function PagamentoPage({ onComplete, onBack }: PagamentoPageProps) {
  const { carrinho, totalCarrinho, usuario, clearCarrinho, addPedido, addPedidoKDS } = useStore();
  const [step, setStep] = useState<PaymentStep>('form');
  const [metodo, setMetodo] = useState<'card' | 'qr'>('card');
  const [confetti, setConfetti] = useState<Array<{ id: number; x: number; color: string; delay: number }>>([]);
  const total = totalCarrinho();

  // Gerar confetti
  useEffect(() => {
    if (step === 'success') {
      const colors = ['#4CAF50', '#2196F3', '#FF9800', '#E91E63', '#9C27B0', '#00BCD4', '#FFD700'];
      const particles = Array.from({ length: 50 }, (_, i) => ({
        id: i,
        x: Math.random() * 100,
        color: colors[Math.floor(Math.random() * colors.length)],
        delay: Math.random() * 2,
      }));
      setConfetti(particles);
    }
  }, [step]);

  const handlePay = () => {
    setStep('processing');
    setTimeout(() => {
      setStep('success');
      // Criar pedido
      const pedidoId = `pwa_${Date.now()}`;
      const pedido = {
        id: pedidoId,
        itens: [...carrinho],
        total,
        estado: 'pendente' as const,
        origem: 'pwa' as const,
        timestamp: Date.now(),
        usuarioId: usuario?.id || '',
        nomeUsuario: usuario?.nome || '',
        emailUsuario: usuario?.email || '',
        metodoPago: metodo === 'card' ? 'Tarjeta' : 'Bizum',
        telefone: usuario?.telefone,
      };
      addPedido(pedido);
      // Add to KDS
      addPedidoKDS({
        id: pedidoId,
        numero: Math.floor(Math.random() * 900) + 100,
        itens: carrinho.map((i) => `${i.quantidade}x ${i.produto.nome}`),
        estado: 'pendente',
        origem: 'pwa',
        timestamp: Date.now(),
        total,
        usuario: { nome: usuario?.nome || '', email: usuario?.email || '', telefone: usuario?.telefone },
      });
      clearCarrinho();
    }, 2500);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50">
      <div className="max-w-lg mx-auto px-4 py-6">
        <button onClick={onBack} className="flex items-center gap-2 text-gray-500 hover:text-gray-700 mb-6">
          <ArrowLeft className="w-5 h-5" />
          <span>Voltar ao cardapio</span>
        </button>

        <AnimatePresence mode="wait">
          {step === 'form' && (
            <motion.div
              key="form"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <h1 className="font-display text-2xl font-bold text-gray-800 mb-1">Pagamento</h1>
              <p className="text-gray-400 text-sm mb-6">Escolha como deseja pagar</p>

              {/* Metodo de pagamento */}
              <div className="bg-white rounded-card shadow-card p-5 mb-4">
                <h3 className="font-medium text-gray-700 mb-3">Metodo de pagamento</h3>
                <div className="space-y-2">
                  <button
                    onClick={() => setMetodo('card')}
                    className={`w-full flex items-center gap-4 p-4 rounded-btn border-2 transition-all ${
                      metodo === 'card' ? 'border-green-400 bg-green-50' : 'border-gray-100 hover:border-gray-200'
                    }`}
                  >
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${metodo === 'card' ? 'bg-green-500 text-white' : 'bg-gray-100 text-gray-400'}`}>
                      <CreditCard className="w-6 h-6" />
                    </div>
                    <div className="text-left">
                      <p className="font-medium text-gray-800">Cartao</p>
                      <p className="text-xs text-gray-400">Visa, Mastercard, AMEX</p>
                    </div>
                    {metodo === 'card' && <Check className="w-5 h-5 text-green-500 ml-auto" />}
                  </button>

                  <button
                    onClick={() => setMetodo('qr')}
                    className={`w-full flex items-center gap-4 p-4 rounded-btn border-2 transition-all ${
                      metodo === 'qr' ? 'border-green-400 bg-green-50' : 'border-gray-100 hover:border-gray-200'
                    }`}
                  >
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${metodo === 'qr' ? 'bg-green-500 text-white' : 'bg-gray-100 text-gray-400'}`}>
                      <QrCode className="w-6 h-6" />
                    </div>
                    <div className="text-left">
                      <p className="font-medium text-gray-800">Bizum / QR</p>
                      <p className="text-xs text-gray-400">Pague com QR code</p>
                    </div>
                    {metodo === 'qr' && <Check className="w-5 h-5 text-green-500 ml-auto" />}
                  </button>
                </div>
              </div>

              {/* Resumo */}
              <div className="bg-white rounded-card shadow-card p-5 mb-6">
                <h3 className="font-medium text-gray-700 mb-3">Resumo do pedido</h3>
                <div className="space-y-2">
                  {carrinho.map((item) => (
                    <div key={item.produto.id} className="flex items-center justify-between text-sm">
                      <span className="text-gray-600">{item.quantidade}x {item.produto.nome}</span>
                      <span className="font-mono text-gray-800">{(item.produto.preco * item.quantidade).toFixed(2)} &euro;</span>
                    </div>
                  ))}
                </div>
                <div className="border-t border-gray-100 mt-3 pt-3 flex items-center justify-between">
                  <span className="font-bold text-gray-800">Total</span>
                  <span className="font-mono font-bold text-xl text-green-600">{total.toFixed(2)} &euro;</span>
                </div>
              </div>

              <motion.button
                onClick={handlePay}
                whileTap={{ scale: 0.98 }}
                className="w-full h-16 btn-primary rounded-btn text-lg font-bold flex items-center justify-center gap-2"
              >
                <Sparkles className="w-5 h-5" />
                Pagar {total.toFixed(2)} &euro;
              </motion.button>
            </motion.div>
          )}

          {step === 'processing' && (
            <motion.div
              key="processing"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="flex flex-col items-center justify-center py-20"
            >
              {/* Spinner animado */}
              <div className="relative w-24 h-24 mb-8">
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                  className="absolute inset-0 rounded-full border-4 border-green-200 border-t-green-500"
                />
                <motion.div
                  animate={{ rotate: -360 }}
                  transition={{ duration: 1.5, repeat: Infinity, ease: 'linear' }}
                  className="absolute inset-2 rounded-full border-4 border-emerald-200 border-b-emerald-500"
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  <CreditCard className="w-8 h-8 text-green-500" />
                </div>
              </div>

              <h2 className="font-display text-xl font-bold text-gray-800 mb-2">Processando pagamento</h2>
              <p className="text-gray-400">Aguarde um momento...</p>

              {/* Barra de progresso */}
              <div className="w-64 h-2 bg-gray-200 rounded-full mt-6 overflow-hidden">
                <motion.div
                  initial={{ width: '0%' }}
                  animate={{ width: '100%' }}
                  transition={{ duration: 2.5, ease: 'easeInOut' }}
                  className="h-full bg-gradient-to-r from-green-400 to-emerald-500 rounded-full"
                />
              </div>
            </motion.div>
          )}

          {step === 'success' && (
            <motion.div
              key="success"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              className="relative flex flex-col items-center justify-center py-16"
            >
              {/* Confetti */}
              {confetti.map((c) => (
                <motion.div
                  key={c.id}
                  initial={{ y: -50, x: `${c.x}vw`, opacity: 1, rotate: 0 }}
                  animate={{
                    y: '100vh',
                    rotate: 720,
                    opacity: [1, 1, 0],
                  }}
                  transition={{
                    duration: 2.5 + Math.random(),
                    delay: c.delay * 0.3,
                    ease: 'easeIn',
                  }}
                  className="fixed top-0 w-3 h-3 rounded-sm z-50"
                  style={{ backgroundColor: c.color, left: `${c.x}%` }}
                />
              ))}

              {/* Check animado */}
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: 'spring', stiffness: 200, damping: 15, delay: 0.3 }}
                className="w-28 h-28 bg-gradient-to-br from-green-400 to-emerald-600 rounded-full flex items-center justify-center shadow-xl mb-6"
              >
                <motion.div
                  initial={{ pathLength: 0 }}
                  animate={{ pathLength: 1 }}
                  transition={{ delay: 0.6, duration: 0.4 }}
                >
                  <Check className="w-14 h-14 text-white" strokeWidth={3} />
                </motion.div>
              </motion.div>

              <motion.h2
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
                className="font-display text-2xl font-bold text-gray-800 mb-2"
              >
                Pedido confirmado!
              </motion.h2>

              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.7 }}
                className="text-gray-400 text-center mb-8"
              >
                Seu pagamento foi processado com sucesso
              </motion.p>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.9 }}
                className="bg-white rounded-card shadow-card p-6 w-full mb-6"
              >
                <div className="flex items-center justify-between mb-3">
                  <span className="text-gray-500">Total pago</span>
                  <span className="font-mono font-bold text-xl text-green-600">{total.toFixed(2)} &euro;</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-500">Metodo</span>
                  <span className="text-gray-700 font-medium">{metodo === 'card' ? 'Cartao' : 'Bizum'}</span>
                </div>
              </motion.div>

              <motion.button
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 1.1 }}
                onClick={onComplete}
                whileTap={{ scale: 0.98 }}
                className="w-full h-14 btn-primary rounded-btn text-base font-bold"
              >
                Rastrear meu pedido
              </motion.button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
