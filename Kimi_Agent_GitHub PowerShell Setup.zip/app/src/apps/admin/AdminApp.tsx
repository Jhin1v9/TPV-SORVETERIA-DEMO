import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useStore } from '@/store/useStore';
import {
  LayoutDashboard, ShoppingBag, Package, Settings,
  TrendingUp, TrendingDown, DollarSign, Users, Clock,
  ArrowLeft, BarChart3, PieChart, AlertTriangle, CheckCircle
} from 'lucide-react';

const navItems = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'pedidos', label: 'Pedidos', icon: ShoppingBag },
  { id: 'estoque', label: 'Estoque', icon: Package },
  { id: 'config', label: 'Config', icon: Settings },
];

function StatCard({ title, value, change, changeType, icon: Icon, color }: any) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100"
    >
      <div className="flex items-center justify-between mb-3">
        <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${color}`}>
          <Icon className="w-5 h-5 text-white" />
        </div>
        <span className={`text-xs font-bold px-2 py-1 rounded-full ${
          changeType === 'up' ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'
        }`}>
          {change}
        </span>
      </div>
      <p className="text-gray-400 text-sm">{title}</p>
      <p className="font-display text-2xl font-bold text-gray-800 mt-1">{value}</p>
    </motion.div>
  );
}

function DashboardView() {
  const { pedidosKDS, pedidosCliente } = useStore();
  const todosPedidos = [...pedidosKDS, ...pedidosCliente.map((p) => ({
    id: p.id,
    numero: parseInt(p.id.slice(-3)) || 0,
    estado: p.estado,
    origem: 'pwa' as const,
    timestamp: p.timestamp,
    total: p.total,
    itens: p.itens.map((i) => `${i.quantidade}x ${i.produto.nome}`),
  }))];

  const totalVendas = todosPedidos.reduce((s, p) => s + p.total, 0);
  const pedidosHoje = todosPedidos.filter((p) => Date.now() - p.timestamp < 86400000).length;
  const pendentes = todosPedidos.filter((p) => p.estado === 'pendente').length;
  const prontos = todosPedidos.filter((p) => p.estado === 'listo').length;

  // Dados mock para grafico
  const vendasSemana = [
    { dia: 'Seg', valor: 245 },
    { dia: 'Ter', valor: 312 },
    { dia: 'Qua', valor: 198 },
    { dia: 'Qui', valor: 456 },
    { dia: 'Sex', valor: 523 },
    { dia: 'Sab', valor: 678 },
    { dia: 'Dom', valor: 389 },
  ];

  return (
    <div className="space-y-6">
      <h2 className="font-display text-2xl font-bold text-gray-800">Dashboard</h2>

      {/* Stats grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Vendas Totais" value={`${totalVendas.toFixed(2)} EUR`} change="+12%" changeType="up" icon={DollarSign} color="bg-green-500" />
        <StatCard title="Pedidos Hoje" value={String(pedidosHoje)} change="+5%" changeType="up" icon={ShoppingBag} color="bg-blue-500" />
        <StatCard title="Pendentes" value={String(pendentes)} change={pendentes > 5 ? "+3" : "-2"} changeType={pendentes > 5 ? 'up' : 'down'} icon={Clock} color="bg-orange-500" />
        <StatCard title="Prontos" value={String(prontos)} change="+8%" changeType="up" icon={CheckCircle} color="bg-purple-500" />
      </div>

      {/* Grafico de vendas */}
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
        <h3 className="font-display font-bold text-gray-800 mb-4">Vendas da Semana</h3>
        <div className="flex items-end gap-3 h-48">
          {vendasSemana.map((v) => {
            const maxVal = Math.max(...vendasSemana.map((x) => x.valor));
            const pct = (v.valor / maxVal) * 100;
            return (
              <div key={v.dia} className="flex-1 flex flex-col items-center gap-2">
                <span className="text-xs font-bold text-gray-500">{v.valor}</span>
                <motion.div
                  initial={{ height: 0 }}
                  animate={{ height: `${pct}%` }}
                  transition={{ duration: 0.5, ease: 'easeOut' }}
                  className="w-full bg-gradient-to-t from-green-400 to-green-300 rounded-t-lg min-h-[8px]"
                />
                <span className="text-xs text-gray-400">{v.dia}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Pedidos recentes */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="p-4 border-b border-gray-50">
          <h3 className="font-display font-bold text-gray-800">Pedidos Recentes</h3>
        </div>
        <div className="divide-y divide-gray-50">
          {todosPedidos.slice(0, 8).map((p) => (
            <div key={p.id} className="p-4 flex items-center justify-between hover:bg-gray-50 transition-colors">
              <div className="flex items-center gap-3">
                <span className={`w-2.5 h-2.5 rounded-full ${
                  p.estado === 'pendente' ? 'bg-blue-400' :
                  p.estado === 'preparando' ? 'bg-orange-400' :
                  p.estado === 'listo' ? 'bg-green-400' :
                  'bg-gray-300'
                }`} />
                <div>
                  <p className="font-mono font-bold text-gray-800">#{String(p.numero || 0).padStart(3, '0')}</p>
                  <p className="text-xs text-gray-400">{p.itens?.[0] || 'Pedido'}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="font-mono font-bold text-gray-800">{p.total.toFixed(2)} EUR</p>
                <span className={`text-xs px-2 py-0.5 rounded-full ${
                  p.origem === 'pwa' ? 'bg-purple-100 text-purple-600' : 'bg-blue-100 text-blue-600'
                }`}>
                  {p.origem === 'pwa' ? 'PWA' : 'TPV'}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function PedidosView() {
  const { pedidosKDS, atualizarEstadoKDS, pedidosCliente } = useStore();
  const [filtro, setFiltro] = useState<'todos' | 'tpv' | 'pwa'>('todos');

  const todosPedidos = [...pedidosKDS, ...pedidosCliente.map((p) => ({
    id: p.id,
    numero: parseInt(p.id.slice(-3)) || 0,
    estado: p.estado,
    origem: 'pwa' as const,
    timestamp: p.timestamp,
    total: p.total,
    itens: p.itens.map((i) => `${i.quantidade}x ${i.produto.nome}`),
    usuario: { nome: p.nomeUsuario, email: p.emailUsuario, telefone: p.telefone },
  }))];

  const filtrados = todosPedidos.filter((p) => {
    if (filtro === 'todos') return true;
    return p.origem === filtro;
  });

  const statusLabels: Record<string, { label: string; color: string }> = {
    pendente: { label: 'Pendente', color: 'bg-blue-100 text-blue-700' },
    preparando: { label: 'Preparando', color: 'bg-orange-100 text-orange-700' },
    listo: { label: 'Pronto', color: 'bg-green-100 text-green-700' },
    entregado: { label: 'Entregue', color: 'bg-gray-100 text-gray-500' },
    cancelado: { label: 'Cancelado', color: 'bg-red-100 text-red-500' },
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="font-display text-2xl font-bold text-gray-800">Todos os Pedidos</h2>
        <div className="flex gap-2">
          {(['todos', 'tpv', 'pwa'] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFiltro(f)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                filtro === f ? 'bg-green-500 text-white' : 'bg-gray-100 text-gray-500 hover:bg-gray-200'
              }`}
            >
              {f === 'todos' ? 'Todos' : f === 'tpv' ? 'TPV Tablet' : 'PWA App'}
            </button>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-100">
                <th className="text-left px-4 py-3 text-xs font-semibold text-gray-400 uppercase">#</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-gray-400 uppercase">Itens</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-gray-400 uppercase">Origem</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-gray-400 uppercase">Status</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-gray-400 uppercase">Total</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-gray-400 uppercase">Acoes</th>
              </tr>
            </thead>
            <tbody>
              {filtrados.map((p) => {
                const st = statusLabels[p.estado] || statusLabels.pendente;
                return (
                  <tr key={p.id} className="border-b border-gray-50 hover:bg-gray-50 transition-colors">
                    <td className="px-4 py-3 font-mono font-bold text-gray-800">#{String(p.numero || 0).padStart(3, '0')}</td>
                    <td className="px-4 py-3 text-sm text-gray-600 max-w-xs truncate">{p.itens?.join(', ')}</td>
                    <td className="px-4 py-3">
                      <span className={`text-xs px-2 py-1 rounded-full ${p.origem === 'pwa' ? 'bg-purple-100 text-purple-600' : 'bg-blue-100 text-blue-600'}`}>
                        {p.origem === 'pwa' ? 'PWA' : 'TPV'}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`text-xs px-2 py-1 rounded-full font-medium ${st.color}`}>{st.label}</span>
                    </td>
                    <td className="px-4 py-3 font-mono font-bold text-gray-800">{p.total.toFixed(2)} EUR</td>
                    <td className="px-4 py-3">
                      {p.estado !== 'entregado' && p.estado !== 'cancelado' && (
                        <button
                          onClick={() => {
                            const seq = ['pendente', 'preparando', 'listo', 'entregado'];
                            const idx = seq.indexOf(p.estado);
                            if (idx >= 0 && idx < seq.length - 1) {
                              atualizarEstadoKDS(p.id, seq[idx + 1] as PedidoKDS['estado']);
                            }
                          }}
                          className="text-xs bg-green-500 text-white px-3 py-1.5 rounded-lg hover:bg-green-600 transition-colors"
                        >
                          Avancar
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function EstoqueView() {
  const { pedidosKDS, pedidosCliente } = useStore();
  const todosPedidos = [...pedidosKDS, ...pedidosCliente.map((p) => ({ ...p, origem: 'pwa' as const, itens: p.itens.map((i) => `${i.quantidade}x ${i.produto.nome}`) }))];

  // Contar produtos mais vendidos
  const contagem: Record<string, number> = {};
  todosPedidos.forEach((p) => {
    p.itens?.forEach((item: string) => {
      const nome = item.replace(/^\d+x\s/, '');
      contagem[nome] = (contagem[nome] || 0) + 1;
    });
  });
  const ranking = Object.entries(contagem).sort((a, b) => b[1] - a[1]).slice(0, 10);

  const maxCount = ranking[0]?.[1] || 1;

  return (
    <div className="space-y-6">
      <h2 className="font-display text-2xl font-bold text-gray-800">Gestao de Estoque</h2>

      {/* Ranking de produtos */}
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
        <h3 className="font-display font-bold text-gray-800 mb-4">Ranking de Produtos Mais Vendidos</h3>
        <div className="space-y-3">
          {ranking.map(([nome, count], idx) => {
            const pct = (count / maxCount) * 100;
            return (
              <div key={nome} className="flex items-center gap-3">
                <span className="w-6 text-center font-bold text-gray-400">{idx + 1}</span>
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-medium text-gray-700">{nome}</span>
                    <span className="text-sm font-bold text-gray-800">{count} vendas</span>
                  </div>
                  <div className="h-2.5 bg-gray-100 rounded-full overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${pct}%` }}
                      transition={{ duration: 0.5, delay: idx * 0.05 }}
                      className="h-full bg-gradient-to-r from-green-400 to-emerald-500 rounded-full"
                    />
                  </div>
                </div>
              </div>
            );
          })}
          {ranking.length === 0 && (
            <p className="text-gray-400 text-center py-8">Nenhuma venda registrada ainda</p>
          )}
        </div>
      </div>

      {/* Alertas */}
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
        <div className="flex items-center gap-2 mb-4">
          <AlertTriangle className="w-5 h-5 text-orange-500" />
          <h3 className="font-display font-bold text-gray-800">Alertas</h3>
        </div>
        <div className="space-y-2">
          <div className="flex items-center gap-3 p-3 bg-orange-50 rounded-xl">
            <span className="text-2xl">⚠️</span>
            <div>
              <p className="font-medium text-gray-800">Estoque baixo: Acai Puro Copinho</p>
              <p className="text-sm text-gray-500">Restam apenas 3 unidades</p>
            </div>
          </div>
          <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-xl">
            <span className="text-2xl">📊</span>
            <div>
              <p className="font-medium text-gray-800">Pico de vendas esperado</p>
              <p className="text-sm text-gray-500">Sabado e Domingo - preparar mais estoque</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function ConfigView() {
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="space-y-6">
      <h2 className="font-display text-2xl font-bold text-gray-800">Configuracoes</h2>

      {saved && (
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="bg-green-100 text-green-700 rounded-xl px-4 py-3 flex items-center gap-2">
          <CheckCircle className="w-5 h-5" />
          Configuracoes salvas com sucesso!
        </motion.div>
      )}

      <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
        <h3 className="font-display font-bold text-gray-800 mb-4">Informacoes do Estabelecimento</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-500 mb-1">Nome</label>
            <input type="text" defaultValue="Tropicale - Gelats Artesanais" className="w-full h-11 px-4 rounded-xl border border-gray-200 focus:border-green-400 outline-none text-sm" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-500 mb-1">Telefone</label>
            <input type="text" defaultValue="+34 612 345 678" className="w-full h-11 px-4 rounded-xl border border-gray-200 focus:border-green-400 outline-none text-sm" />
          </div>
          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-gray-500 mb-1">Endereco</label>
            <input type="text" defaultValue="Carrer de la Concepcio, 23, 08201 Sabadell, Barcelona" className="w-full h-11 px-4 rounded-xl border border-gray-200 focus:border-green-400 outline-none text-sm" />
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
        <h3 className="font-display font-bold text-gray-800 mb-4">Horario de Funcionamento</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="flex items-center gap-4 bg-gray-50 rounded-xl p-4">
            <span className="text-2xl">Verão</span>
            <div>
              <p className="text-sm font-medium text-gray-700">Junho - Setembro</p>
              <p className="text-sm text-gray-400">16:00 - 23:00</p>
            </div>
          </div>
          <div className="flex items-center gap-4 bg-gray-50 rounded-xl p-4">
            <span className="text-2xl">Inverno</span>
            <div>
              <p className="text-sm font-medium text-gray-700">Outubro - Maio</p>
              <p className="text-sm text-gray-400">17:00 - 22:00</p>
            </div>
          </div>
        </div>
      </div>

      <button onClick={handleSave} className="h-12 px-8 btn-primary rounded-btn font-bold">
        Salvar Configuracoes
      </button>
    </div>
  );
}

export default function AdminApp() {
  const { setView } = useStore();
  const [activeTab, setActiveTab] = useState('dashboard');

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top bar */}
      <header className="sticky top-0 z-50 bg-white border-b border-gray-100">
        <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button onClick={() => setView('selector')} className="p-2 -ml-2 text-gray-400 hover:text-gray-600">
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-br from-green-400 to-emerald-600 rounded-lg flex items-center justify-center">
                <LayoutDashboard className="w-4 h-4 text-white" />
              </div>
              <span className="font-display font-bold text-gray-800">Admin Tropicale</span>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-4 py-6 flex gap-6">
        {/* Sidebar */}
        <nav className="hidden lg:block w-56 flex-shrink-0">
          <div className="sticky top-24 space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all ${
                    activeTab === item.id ? 'bg-green-500 text-white shadow-btn' : 'text-gray-500 hover:bg-gray-100'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  {item.label}
                </button>
              );
            })}
          </div>
        </nav>

        {/* Mobile nav */}
        <div className="lg:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-100 z-50">
          <div className="flex justify-around py-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`flex flex-col items-center gap-1 px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                    activeTab === item.id ? 'text-green-600' : 'text-gray-400'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  {item.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Content */}
        <main className="flex-1 min-w-0 pb-20 lg:pb-0">
          <AnimatePresence mode="wait">
            {activeTab === 'dashboard' && <DashboardView key="dash" />}
            {activeTab === 'pedidos' && <PedidosView key="pedidos" />}
            {activeTab === 'estoque' && <EstoqueView key="estoque" />}
            {activeTab === 'config' && <ConfigView key="config" />}
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
}
