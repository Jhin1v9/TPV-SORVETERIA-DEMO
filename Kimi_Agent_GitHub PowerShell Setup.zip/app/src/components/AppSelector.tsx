import { motion } from 'framer-motion';
import { useStore } from '@/store/useStore';
import { Smartphone, ChefHat, Monitor, LayoutDashboard } from 'lucide-react';

export default function AppSelector() {
  const { setView } = useStore();

  const apps = [
    {
      id: 'cliente' as const,
      title: 'App Cliente PWA',
      subtitle: 'Cardápio e pedidos online',
      description: 'Para clientes fazerem pedidos pelo celular',
      icon: Smartphone,
      color: 'from-green-400 to-emerald-600',
      iconBg: 'bg-green-50',
    },
    {
      id: 'cocina' as const,
      title: 'Cozinha KDS',
      subtitle: 'Kitchen Display System',
      description: 'Gerenciamento de pedidos em tempo real',
      icon: ChefHat,
      color: 'from-orange-400 to-amber-600',
      iconBg: 'bg-orange-50',
    },
    {
      id: 'kiosk' as const,
      title: 'Kiosk Tablet 21"',
      subtitle: 'Terminal autoatendimento',
      description: 'Interface otimizada para telas grandes',
      icon: Monitor,
      color: 'from-blue-400 to-indigo-600',
      iconBg: 'bg-blue-50',
    },
    {
      id: 'admin' as const,
      title: 'Admin Dashboard',
      subtitle: 'Painel administrativo',
      description: 'Vendas, estoque e configuracoes',
      icon: LayoutDashboard,
      color: 'from-purple-400 to-violet-600',
      iconBg: 'bg-purple-50',
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-gray-100 flex items-center justify-center p-4">
      <div className="max-w-lg w-full">
        {/* Logo */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-10"
        >
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: 'spring', stiffness: 200 }}
            className="w-20 h-20 mx-auto mb-5 bg-gradient-to-br from-green-400 to-emerald-600 rounded-2xl flex items-center justify-center shadow-lg"
          >
            <svg viewBox="0 0 40 40" className="w-12 h-12" fill="none">
              <path d="M20 8 C12 8, 8 14, 8 20 C8 28, 12 32, 20 32 C28 32, 32 28, 32 20 C32 14, 28 8, 20 8Z" fill="white" opacity="0.9"/>
              <path d="M14 18 Q20 30 26 18" stroke="#3E2723" strokeWidth="2.5" fill="none" strokeLinecap="round"/>
              <circle cx="16" cy="15" r="1.5" fill="#4CAF50"/>
              <circle cx="24" cy="14" r="1.5" fill="#8D6E63"/>
            </svg>
          </motion.div>
          <h1 className="font-display text-3xl font-bold text-gray-800">Tropicale</h1>
          <p className="text-gray-400 mt-1">Gelats Artesanais - Sistema TPV</p>
        </motion.div>

        {/* 4 Cards */}
        <div className="space-y-3">
          {apps.map((app, idx) => {
            const Icon = app.icon;
            return (
              <motion.button
                key={app.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.08 }}
                whileHover={{ scale: 1.02, y: -2 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => setView(app.id)}
                className="w-full flex items-center gap-4 p-5 bg-white rounded-2xl shadow-sm border border-gray-100 hover:shadow-md transition-all text-left"
              >
                <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${app.color} flex items-center justify-center flex-shrink-0`}>
                  <Icon className="w-7 h-7 text-white" />
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-display font-bold text-gray-800">{app.title}</h3>
                  <p className="text-xs text-gray-400 font-medium">{app.subtitle}</p>
                  <p className="text-sm text-gray-500 mt-0.5">{app.description}</p>
                </div>
                <svg className="w-5 h-5 text-gray-300 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
                </svg>
              </motion.button>
            );
          })}
        </div>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="text-center text-gray-300 text-xs mt-8"
        >
          Tropicale Gelats Artesanais - Sabadell 2026 - UTF-8
        </motion.p>
      </div>
    </div>
  );
}
